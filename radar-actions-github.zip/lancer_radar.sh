#!/usr/bin/env bash
# Lancement sur macOS / Linux
cd "$(dirname "$0")"
PY=$(command -v python3 || command -v python)
[ -z "$PY" ] && { echo "Python 3 introuvable."; exit 1; }
[ -x .venv/bin/python ] || "$PY" -m venv .venv
if ! cmp -s requirements.txt .venv/req_installed.txt; then
  .venv/bin/python -m pip install --upgrade pip >/dev/null
  .venv/bin/python -m pip install -r requirements.txt && cp requirements.txt .venv/req_installed.txt
fi
exec .venv/bin/python app.py
