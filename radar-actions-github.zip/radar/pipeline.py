"""Orchestration du scan : univers → données → indicateurs → filtres → régime → signaux → sélection."""
from __future__ import annotations

import json
import math
import threading
import traceback
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from . import data as D
from .config import (SCANS_DIR, DEFAULT_SETTINGS, REGIME_INDICES, REGIME_EXTRA, SUFFIX_BENCHMARK,
                     EUROPE_FALLBACK_BENCHMARK, FX_TICKERS, US_SECTOR_ETF, CATEGORY_LABELS)
from .indicators import build_group_panels, group_by_calendar, compute_wide, latest_metrics
from .signals import classify
from .universe import build_universe, suffix_of, region_of, market_of

try:
    from zoneinfo import ZoneInfo
    PARIS = ZoneInfo("Europe/Paris")
except Exception:  # tzdata absent
    PARIS = None


def now_paris() -> datetime:
    return datetime.now(PARIS) if PARIS else datetime.now()


def clean(o):
    """Rend un objet sérialisable en JSON (NaN -> None, numpy -> Python)."""
    if isinstance(o, dict):
        return {str(k): clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating, float)):
        f = float(o)
        return None if not math.isfinite(f) else round(f, 6)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, (pd.Timestamp, datetime)):
        return o.isoformat()
    if isinstance(o, np.ndarray):
        return clean(o.tolist())
    return o


class ScanJob:
    """Scan exécuté dans un thread ; l'état est interrogé par l'interface."""

    def __init__(self):
        self.lock = threading.Lock()
        self.running = False
        self.progress = 0.0
        self.stage = "En attente"
        self.logs: list[str] = []
        self.error = None
        self.result = None
        self.prices: dict = {}
        self.thread = None

    def log(self, msg: str):
        with self.lock:
            self.logs.append(f"{now_paris():%H:%M:%S}  {msg}")
            self.logs = self.logs[-300:]

    def set(self, stage=None, progress=None):
        with self.lock:
            if stage is not None:
                self.stage = stage
            if progress is not None:
                self.progress = float(progress)

    def status(self):
        with self.lock:
            return {"running": self.running, "progress": round(self.progress, 1), "stage": self.stage,
                    "logs": self.logs[-60:], "error": self.error,
                    "has_result": self.result is not None}

    def start(self, settings: dict, use_cache=True):
        if self.running:
            return False
        self.running, self.error, self.logs, self.progress = True, None, [], 0
        self.thread = threading.Thread(target=self._run, args=(settings, use_cache), daemon=True)
        self.thread.start()
        return True

    def _run(self, settings, use_cache):
        try:
            res, prices = run_scan(settings, use_cache, self)
            with self.lock:
                self.result = res
                self.prices = prices
            self.set("Terminé", 100)
            self.log("Scan terminé.")
        except Exception as exc:
            self.error = f"{exc}"
            self.log("ERREUR : " + str(exc))
            self.log(traceback.format_exc()[-1500:])
            self.set("Erreur")
        finally:
            self.running = False


# ---------------------------------------------------------------------------
def _series_ret(df: pd.DataFrame | None, n: int) -> float:
    if df is None or len(df) <= n:
        return np.nan
    c = df["Close"].dropna()
    if len(c) <= n:
        return np.nan
    return float(c.iloc[-1] / c.iloc[-1 - n] - 1)


def _index_state(df: pd.DataFrame | None) -> dict | None:
    if df is None or len(df) < 200:
        return None
    c = df["Close"].dropna()
    if len(c) < 200:
        return None
    last = float(c.iloc[-1])
    ma50, ma200 = float(c.iloc[-50:].mean()), float(c.iloc[-200:].mean())
    return {"close": last, "ma50": ma50, "ma200": ma200, "above_ma50": last > ma50,
            "above_ma200": last > ma200, "ret_1m": _series_ret(df, 21), "ret_3m": _series_ret(df, 63),
            "date": c.index[-1].strftime("%Y-%m-%d")}


def market_regime(bench: dict, breadth: dict) -> dict:
    idx = {name: _index_state(bench.get(tk)) for tk, name in REGIME_INDICES.items()}
    vix_df = bench.get("^VIX")
    vix = float(vix_df["Close"].dropna().iloc[-1]) if vix_df is not None and len(vix_df) else np.nan
    tnx_df = bench.get("^TNX")
    tnx = float(tnx_df["Close"].dropna().iloc[-1]) if tnx_df is not None and len(tnx_df) else np.nan
    spx, stoxx = idx.get("S&P 500"), idx.get("STOXX 600")
    b_vals = [v["above_ma50"] for v in breadth.values() if v.get("above_ma50") is not None]
    b = float(np.mean(b_vals)) if b_vals else np.nan
    main = [x for x in (spx, stoxx) if x]
    reasons = []
    if not main:
        regime = "neutre"
        reasons.append("indices de référence indisponibles : régime neutre par défaut")
    else:
        all_up = all(x["above_ma200"] for x in main)
        all_down = all(not x["above_ma200"] for x in main)
        bull = all_up and (not np.isfinite(b) or b >= 0.5) and (not np.isfinite(vix) or vix < 20)
        bear = all_down or (np.isfinite(b) and b < 0.30) or (np.isfinite(vix) and vix > 30)
        regime = "baissier" if bear else ("haussier" if bull else "neutre")
        for name, x in (("S&P 500", spx), ("STOXX 600", stoxx)):
            if x:
                reasons.append(f"{name} {'au-dessus' if x['above_ma200'] else 'en dessous'} de sa MA200"
                               f" ({'au-dessus' if x['above_ma50'] else 'en dessous'} de sa MA50)")
        if np.isfinite(b):
            reasons.append(f"{b:.0%} des titres analysés au-dessus de leur MA50")
        if np.isfinite(vix):
            reasons.append(f"VIX à {vix:.1f}")
    implications = {
        "haussier": "Toutes les catégories sont exploitables ; breakouts et momentum favorisés.",
        "neutre": "Sélectivité accrue ; privilégier les setups avec catalyseur et R/R élevé.",
        "baissier": "R/R minimum relevé à 3, breakouts/momentum en watchlist sauf force relative exceptionnelle, 5 titres maximum.",
    }[regime]
    return {"regime": regime, "reasons": reasons, "implications": implications, "indices": idx,
            "vix": vix, "us10y": tnx / 10 if np.isfinite(tnx) and tnx > 20 else tnx, "breadth": breadth}


# ---------------------------------------------------------------------------
def run_scan(settings: dict, use_cache: bool, job: ScanJob | None = None):
    st = dict(DEFAULT_SETTINGS)
    st.update(settings or {})
    for k in ("preselect_n", "max_retained", "max_retained_bear", "max_per_sector",
              "earnings_warning_days", "min_history_days", "chunk_size"):
        st[k] = int(round(float(st[k])))
    log = job.log if job else print
    setp = job.set if job else (lambda *a, **k: None)
    started = now_paris()
    provider = D.get_provider()
    log(f"Source de données : {provider.name}")

    # 1. Univers
    setp("Construction de l'univers", 2)
    uni = build_universe(st, log)
    tickers = uni["tickers"]
    log(f"Univers identifié : {len(tickers)} titres ({', '.join(f'{k} {v}' for k, v in uni['by_region'].items())})")
    if not tickers:
        raise RuntimeError("Univers vide : cochez au moins une région.")

    # 2. Données
    suffixes = {suffix_of(t) for t in tickers}
    bench_tk = set(REGIME_INDICES) | set(REGIME_EXTRA) | {EUROPE_FALLBACK_BENCHMARK}
    bench_tk |= {SUFFIX_BENCHMARK[s] for s in suffixes if s in SUFFIX_BENCHMARK}
    bench_tk |= {v[0] for v in FX_TICKERS.values()}
    if "" in suffixes:
        bench_tk |= set(US_SECTOR_ETF.values())
    all_tk = list(bench_tk) + tickers
    start = (datetime.now() - timedelta(days=420)).strftime("%Y-%m-%d")
    setp("Téléchargement des cours", 5)
    prices, fetched_at = D.fetch_prices(
        provider, all_tk, start, st, use_cache=use_cache,
        progress=lambda k, n: setp(f"Téléchargement des cours (lot {k}/{n})", 5 + 55 * k / n), log=log)
    n_trim = D.trim_incomplete_sessions(prices)
    if n_trim:
        log(f"Séance du jour en cours ignorée pour {n_trim} titres (seules les séances clôturées sont prises en compte).")
    bench = {t: prices.get(t) for t in bench_tk}
    fx, fx_est = D.fx_to_usd(prices)
    if fx_est:
        log(f"Taux de change estimés (non téléchargés) : {', '.join(fx_est)}")

    # 3. Indicateurs par calendrier de place
    setp("Calcul des indicateurs", 62)
    have = [t for t in tickers if t in prices]
    no_data = [t for t in tickers if t not in prices]
    metrics, series_store = [], {}
    groups = group_by_calendar(have)
    for gi, (suf, gt) in enumerate(groups.items()):
        panels = build_group_panels(prices, gt)
        if panels["Close"].empty:
            continue
        w = compute_wide(panels)
        m = latest_metrics(panels, w)
        m["suffix"] = "" if suf == "US" else suf
        metrics.append(m)
        series_store[suf] = (panels, w)
        setp(None, 62 + 8 * (gi + 1) / len(groups))
    M = pd.concat(metrics) if metrics else pd.DataFrame()
    log(f"Indicateurs calculés pour {len(M)} titres.")

    # 4. Filtres
    setp("Filtres de liquidité", 71)
    M["currency"] = [D.currency_of(t) for t in M.index]
    M["fx"] = M["currency"].map(fx)
    M["region"] = [region_of(t) for t in M.index]
    M["market"] = [market_of(t) for t in M.index]
    M["close_usd"] = M["close"] * M["fx"]
    M["adv_usd"] = M["vavg20"] * M["close"] * M["fx"]
    group_last = M.groupby("suffix")["date"].transform("max")
    stale = pd.to_datetime(M["last_real"], errors="coerce") < pd.to_datetime(group_last) - pd.Timedelta(days=6)
    excl = {}
    mask_hist = M["n_obs"] < st["min_history_days"]
    excl["historique insuffisant (< %d séances)" % st["min_history_days"]] = list(M.index[mask_hist])
    mask_stale = ~mask_hist & stale
    excl["sans cotation récente (suspension ?)"] = list(M.index[mask_stale])
    mask_price = ~mask_hist & ~mask_stale & (M["close_usd"] < st["min_price_usd"])
    excl[f"cours < {st['min_price_usd']:.0f} $ (équivalent)"] = list(M.index[mask_price])
    min_adv = np.where(M["region"] == "USA", st["min_adv_usd_us"], st["min_adv_usd_other"])
    mask_liq = ~mask_hist & ~mask_stale & ~mask_price & ~(M["adv_usd"] >= min_adv)
    excl["liquidité insuffisante (volume moyen 20 j en valeur)"] = list(M.index[mask_liq])
    ok = M[~(mask_hist | mask_stale | mask_price | mask_liq)].copy()
    log(f"{len(ok)} titres passent les filtres de cours, d'historique et de liquidité.")

    # Force relative vs indice local
    for n, k in [(21, "1m"), (63, "3m"), (126, "6m")]:
        bret = {}
        for suf in ok["suffix"].unique():
            btk = SUFFIX_BENCHMARK.get(suf)
            r = _series_ret(bench.get(btk), n)
            if not np.isfinite(r) and region_of("X." + suf if suf else "X") == "Europe":
                r = _series_ret(bench.get(EUROPE_FALLBACK_BENCHMARK), n)
            bret[suf] = r
        ok[f"bench_ret_{k}"] = ok["suffix"].map(bret)
        ret_col = {"1m": "ret_1m", "3m": "ret_3m", "6m": "ret_6m"}[k]
        ok[f"rs_{k}"] = ok[ret_col] - ok[f"bench_ret_{k}"].fillna(0)
        ok[f"p_rs_{k}"] = ok.groupby("region")[f"rs_{k}"].rank(pct=True)
    ok["benchmark"] = [SUFFIX_BENCHMARK.get(s) for s in ok["suffix"]]

    # 5. Régime de marché
    setp("Régime de marché", 74)
    breadth = {}
    for reg, g in ok.groupby("region"):
        breadth[reg] = {"n": int(len(g)), "above_ma50": float((g["close"] > g["ma50"]).mean()),
                        "above_ma200": float((g["close"] > g["ma200"]).mean())}
    regime = market_regime(bench, breadth)
    log(f"Régime de marché : {regime['regime']}")

    # 6. Signaux
    setp("Détection des setups", 76)
    signals = []
    idx_list = list(ok.index)
    for i, t in enumerate(idx_list):
        suf = ok.at[t, "suffix"] or "US"
        panels, w = series_store[suf]
        df = pd.DataFrame({f: panels[f][t] for f in ("Open", "High", "Low", "Close", "Volume")}).dropna(subset=["Close"])
        if len(df) < 60:
            continue
        rsi = w["rsi"][t].reindex(df.index)
        relvol = w["relvol"][t].reindex(df.index)
        row = ok.loc[t]
        p1, p3, p6 = (float(row.get(f"p_rs_{k}", 0.5)) if np.isfinite(row.get(f"p_rs_{k}", np.nan)) else 0.5
                      for k in ("1m", "3m", "6m"))
        try:
            res = classify(row, df, rsi, relvol, p1, p3, p6, regime["regime"])
        except Exception as exc:
            log(f"{t} : erreur d'analyse ({exc})")
            continue
        if res:
            res["ticker"] = t
            signals.append(res)
        if i % 200 == 0:
            setp(None, 76 + 6 * i / max(1, len(idx_list)))
    log(f"{len(signals)} titres déclenchent au moins un setup.")
    S = pd.DataFrame(signals).set_index("ticker") if signals else pd.DataFrame()

    # 7. Pré-sélection et enrichissement
    retained, watch, preselected, infos = [], [], [], {}
    excluded_mcap = []
    if len(S):
        S = S.sort_values("prescore", ascending=False)
        top = list(S.index[: st["preselect_n"]])
        for cat in "ABCD":
            top += list(S[S["category"] == cat].index[:8])
        preselected = list(dict.fromkeys(top))
        setp("Enrichissement (capitalisation, secteur, résultats)", 83)
        log(f"Enrichissement de {len(preselected)} titres présélectionnés…")
        infos = D.fetch_infos(provider, preselected,
                              progress=lambda k, n: setp(None, 83 + 12 * k / n), log=log)

    def mcap_usd(t, info):
        cur = D.currency_of(t)
        major = fx["GBP"] if cur == "GBp" else fx.get(cur, np.nan)
        mc = info.get("market_cap")
        so = info.get("shares_out")
        via_shares = so * ok.at[t, "close"] * fx.get(cur, np.nan) if so else np.nan
        if mc:
            v = mc * major
            if np.isfinite(via_shares) and via_shares > 0 and v / via_shares > 20:
                return via_shares
            return v
        return via_shares

    setp("Sélection finale", 96)
    today = now_paris().date()
    min_rr = st["min_rr_bear"] if regime["regime"] == "baissier" else st["min_rr"]
    max_ret = st["max_retained_bear"] if regime["regime"] == "baissier" else st["max_retained"]
    sector_count: dict[str, int] = {}
    rows = []
    for t in preselected:
        s = S.loc[t].to_dict()
        r = ok.loc[t]
        info = infos.get(t, {}) or {}
        mc = mcap_usd(t, info)
        e_date = info.get("earnings_date")
        days_to_e = (datetime.strptime(e_date, "%Y-%m-%d").date() - today).days if e_date else None
        flags = []
        if days_to_e is not None and 0 <= days_to_e <= st["earnings_warning_days"]:
            flags.append("ÉVÉNEMENT BINAIRE : résultats le " + e_date)
        if r["ret_1m"] > 0.15 and r["atr_pct"] < 0.01 and r["bbw"] < 0.03:
            flags.append("volatilité anormalement faible après hausse : possible offre publique, à vérifier")
        # force relative secteur (US)
        sect = info.get("sector")
        rs_sector = {}
        if r["region"] == "USA" and sect in US_SECTOR_ETF:
            etf = bench.get(US_SECTOR_ETF[sect])
            for n, k in [(21, "1m"), (63, "3m"), (126, "6m")]:
                er = _series_ret(etf, n)
                rs_sector[k] = r[{"1m": "ret_1m", "3m": "ret_3m", "6m": "ret_6m"}[k]] - er if np.isfinite(er) else np.nan
        # taille de position indicative
        risk_ps = (s["entry"] - s["stop"]) * fx.get(D.currency_of(t), np.nan) / fx["EUR"]
        risk_eur = st["capital_eur"] * st["risk_pct"] / 100
        shares = int(risk_eur // risk_ps) if risk_ps and np.isfinite(risk_ps) and risk_ps > 0 else 0
        notional = shares * s["entry"] * fx.get(D.currency_of(t), np.nan) / fx["EUR"]
        if np.isfinite(notional) and notional > st["capital_eur"] and s["entry"] > 0:
            shares = int(st["capital_eur"] / (s["entry"] * fx[D.currency_of(t)] / fx["EUR"]))
            notional = shares * s["entry"] * fx[D.currency_of(t)] / fx["EUR"]
            flags.append("taille limitée par le capital (stop très serré)")
        reasons = []
        if not np.isfinite(mc):
            reasons.append("capitalisation n.d.")
        elif mc < st["min_mcap_usd"]:
            reasons.append("capitalisation < %.0f M$" % (st["min_mcap_usd"] / 1e6))
            excluded_mcap.append(t)
        qt = info.get("quote_type")
        if qt and qt not in ("EQUITY",):
            reasons.append(f"type de titre {qt}")
        if not (np.isfinite(s["rr"]) and s["rr"] >= min_rr):
            reasons.append(f"R/R {s['rr']:.1f} < {min_rr:.0f}" if np.isfinite(s["rr"]) else "R/R n.d.")
        if s["prescore"] < st["min_prescore_retain"]:
            reasons.append(f"pré-score < {st['min_prescore_retain']}")
        if s["category"] == "C" and s["status"] == "déclenchement en attente":
            reasons.append("cassure pas encore déclenchée")
        if regime["regime"] == "baissier" and s["category"] in ("C", "D") and r.get("p_rs_6m", 0) < 0.9:
            reasons.append("régime baissier : force relative insuffisante")
        if any("offre publique" in f for f in flags):
            reasons.append("possible offre publique")
        row = {
            "ticker": t, "name": info.get("name"), "market": r["market"], "region": r["region"],
            "currency": D.currency_of(t), "date": r["date"], "close": r["close"],
            "sector": sect, "industry": info.get("industry"), "market_cap_usd": mc,
            "ret_1d": r["ret_1d"], "ret_5d": r["ret_5d"], "ret_1m": r["ret_1m"], "ret_3m": r["ret_3m"],
            "ret_6m": r["ret_6m"], "ret_ytd": r["ret_ytd"], "ret_1y": r["ret_1y"],
            "dist_high52": r["dist_high52"], "rsi": r["rsi"], "atr": r["atr"], "atr_pct": r["atr_pct"],
            "adx": r["adx"], "macd_hist": r["macd_hist"], "relvol": r["relvol"],
            "ma20": r["ma20"], "ma50": r["ma50"], "ma200": r["ma200"], "ema20": r["ema20"],
            "adv_usd": r["adv_usd"], "benchmark": r["benchmark"],
            "rs_1m": r["rs_1m"], "rs_3m": r["rs_3m"], "rs_6m": r["rs_6m"],
            "p_rs_3m": r["p_rs_3m"], "p_rs_6m": r["p_rs_6m"],
            "rs_sector_1m": rs_sector.get("1m"), "rs_sector_3m": rs_sector.get("3m"),
            "rs_sector_6m": rs_sector.get("6m"),
            "forward_pe": info.get("forward_pe"), "trailing_pe": info.get("trailing_pe"),
            "ev_ebitda": info.get("ev_ebitda"), "revenue_growth": info.get("revenue_growth"),
            "profit_margin": info.get("profit_margin"), "short_pct_float": info.get("short_pct_float"),
            "reco_mean": info.get("reco_mean"), "n_analysts": info.get("n_analysts"),
            "earnings_date": e_date, "days_to_earnings": days_to_e,
            "ex_dividend_date": info.get("ex_dividend_date"),
            "position_shares": shares, "position_eur": notional,
            "flags": flags, "not_retained_reasons": reasons, **s,
        }
        rows.append(row)

    rows.sort(key=lambda x: -x["prescore"])
    for row in rows:
        blockers = list(row["not_retained_reasons"])
        sect = row["sector"] or "n.d."
        if not blockers and len(retained) < max_ret:
            if sector_count.get(sect, 0) >= st["max_per_sector"] and sect != "n.d.":
                row["not_retained_reasons"].append("secteur déjà représenté (2 titres max)")
            else:
                retained.append(row)
                sector_count[sect] = sector_count.get(sect, 0) + 1
                continue
        elif not blockers:
            row["not_retained_reasons"].append("nombre maximal de titres retenus atteint")
        if row["prescore"] >= st["min_prescore_watch"] or row["status"] == "déclenchement en attente":
            if not any(r.startswith("capitalisation <") or r.startswith("type de titre") for r in row["not_retained_reasons"]):
                watch.append(row)
    watch = watch[:30]

    # Corrélations entre titres retenus (60 séances)
    corr_pairs = []
    if len(retained) > 1:
        rets = pd.DataFrame({x["ticker"]: prices[x["ticker"]]["Close"].pct_change().iloc[-60:]
                             for x in retained}).dropna(how="all")
        c = rets.corr(min_periods=30)
        tk = list(c.columns)
        for i in range(len(tk)):
            for j in range(i + 1, len(tk)):
                v = c.iat[i, j]
                if np.isfinite(v) and v > 0.7:
                    corr_pairs.append({"a": tk[i], "b": tk[j], "corr": float(v)})

    # 8. Couverture
    def by_region(lst):
        out: dict[str, int] = {}
        for t in lst:
            out[region_of(t)] = out.get(region_of(t), 0) + 1
        return out

    signals_by_cat = S["category"].value_counts().to_dict() if len(S) else {}
    last_sessions = M.groupby("market")["date"].max().to_dict() if len(M) else {}
    n_ident = len(tickers)
    coverage = {
        "universe_identified": n_ident, "universe_by_region": uni["by_region"], "universe_sources": uni["sources"],
        "downloaded": len(have), "downloaded_by_region": by_region(have),
        "no_data": len(no_data), "no_data_sample": no_data[:40],
        "exclusions": {k: len(v) for k, v in excl.items()},
        "scanned": len(ok), "scanned_by_region": by_region(list(ok.index)),
        "signals": len(S), "signals_by_category": signals_by_cat,
        "preselected": len(preselected), "enriched": len(infos),
        "excluded_mcap": len(excluded_mcap), "deep_ai": 0,
        "retained": len(retained), "watchlist": len(watch),
        "coverage_pct": 100.0 * len(have) / n_ident if n_ident else 0,
        "partial": any("pas la cote complète" in s or "liste intégrée" in s for s in uni["sources"].values()) or len(no_data) > 0,
    }
    pipeline_txt = (f"{n_ident} identifiées → {len(have)} téléchargées → {len(ok)} analysées → "
                    f"{len(S)} signaux → {len(preselected)} présélectionnées → "
                    f"0 approfondies (étape IA) → {len(retained)} retenues")

    all_signals = []
    if len(S):
        for t, s in S.head(600).iterrows():
            r = ok.loc[t]
            all_signals.append({"ticker": t, "market": r["market"], "category": s["category"],
                                "prescore": s["prescore"], "close": r["close"], "currency": r["currency"],
                                "ret_1d": r["ret_1d"], "ret_1m": r["ret_1m"], "rsi": r["rsi"],
                                "relvol": r["relvol"], "rr": s["rr"], "status": s["status"],
                                "notes": s["signal_notes"]})

    finished = now_paris()
    result = {
        "meta": {
            "started": started.isoformat(), "finished": finished.isoformat(),
            "started_label": started.strftime("%d/%m/%Y %H:%M") + (" (Europe/Paris)" if PARIS else " (heure locale)"),
            "provider": provider.name, "demo": D.DEMO, "prices_fetched_at": fetched_at.isoformat() if fetched_at else None,
            "last_sessions": last_sessions, "fx": fx, "fx_estimated": fx_est,
            "fundamentals_note": "Ratios Yahoo Finance du jour (derniers comptes publiés, date exacte non fournie par la source).",
            "settings": st, "min_rr": min_rr, "max_retained": max_ret,
        },
        "regime": regime, "coverage": coverage, "pipeline": pipeline_txt,
        "retained": retained, "watchlist": watch, "correlations": corr_pairs,
        "all_signals": all_signals, "category_labels": CATEGORY_LABELS,
        "logs": job.logs[-100:] if job else [],
    }
    result = clean(result)
    stamp = finished.strftime("%Y%m%d_%H%M")
    (SCANS_DIR / f"scan_{stamp}.json").write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    (SCANS_DIR / "dernier_scan.json").write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    return result, prices
