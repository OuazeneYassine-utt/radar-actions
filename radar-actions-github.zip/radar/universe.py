"""Construction de l'univers de titres."""
from __future__ import annotations

import io
import re
import time
from datetime import datetime

import pandas as pd
import requests

from .config import UNIVERSE_DIR, CACHE_DIR, SUFFIX_MARKET, SUFFIX_REGION

NASDAQ_URLS = {
    "nasdaq": "https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqlisted.txt",
    "other": "https://www.nasdaqtrader.com/dynamic/SymDir/otherlisted.txt",
}
EXCLUDE_NAME = re.compile(
    r"\b(warrant|warrants|right|rights|unit|units|preferred|pfd|notes?|debentures?|"
    r"trust preferred|subordinated|acquisition corp)\b|\d+(\.\d+)?\s*%",
    re.IGNORECASE,
)
TICKER_OK = re.compile(r"^[A-Z0-9][A-Z0-9\-\.&]{0,14}$")


def suffix_of(ticker: str) -> str:
    if "." in ticker:
        suf = ticker.rsplit(".", 1)[1]
        if suf in SUFFIX_MARKET:
            return suf
    return ""


def market_of(ticker: str) -> str:
    return SUFFIX_MARKET.get(suffix_of(ticker), "USA")


def region_of(ticker: str) -> str:
    return SUFFIX_REGION.get(suffix_of(ticker), "USA")


def read_list_file(name: str) -> list[str]:
    path = UNIVERSE_DIR / name
    if not path.exists():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip()
        for tok in line.replace(",", " ").split():
            tok = tok.strip().upper()
            if TICKER_OK.match(tok):
                out.append(tok)
    return list(dict.fromkeys(out))


def _fetch_nasdaq_file(url: str) -> pd.DataFrame:
    r = requests.get(url, timeout=30, headers={"User-Agent": "Mozilla/5.0 RadarActions"})
    r.raise_for_status()
    text = "\n".join(l for l in r.text.splitlines() if not l.startswith("File Creation Time"))
    return pd.read_csv(io.StringIO(text), sep="|", dtype=str).fillna("")


def us_full_universe(log=print) -> tuple[list[str], str]:
    """Liste complète NYSE / Nasdaq / NYSE American (actions ordinaires, hors ETF et tests).

    Retourne (tickers, source). Mise en cache une fois par jour.
    """
    cache = CACHE_DIR / f"us_universe_{datetime.now():%Y%m%d}.txt"
    if cache.exists():
        tick = cache.read_text().split()
        return tick, "nasdaqtrader.com (cache du jour)"
    try:
        nas = _fetch_nasdaq_file(NASDAQ_URLS["nasdaq"])
        oth = _fetch_nasdaq_file(NASDAQ_URLS["other"])
    except Exception as exc:  # réseau, format...
        log(f"Liste complète USA indisponible ({exc}); utilisation de la liste intégrée.")
        return read_list_file("usa_rapide.txt"), "liste intégrée (secours : nasdaqtrader.com indisponible)"

    tickers = []
    nas = nas[(nas.get("Test Issue", "N") == "N") & (nas.get("ETF", "N") == "N")]
    if "Financial Status" in nas.columns:
        nas = nas[nas["Financial Status"] != "Q"]  # Q = faillite
    for sym, name in zip(nas["Symbol"], nas["Security Name"]):
        if sym and "$" not in sym and not EXCLUDE_NAME.search(name):
            tickers.append(sym.replace(".", "-"))
    oth = oth[(oth.get("Test Issue", "N") == "N") & (oth.get("ETF", "N") == "N")]
    oth = oth[oth["Exchange"].isin(["N", "A"])]  # NYSE, NYSE American
    for sym, name in zip(oth["ACT Symbol"], oth["Security Name"]):
        if sym and "$" not in sym and not EXCLUDE_NAME.search(name):
            tickers.append(sym.replace(".", "-"))
    tickers = [t for t in dict.fromkeys(tickers) if TICKER_OK.match(t)]
    cache.write_text(" ".join(tickers))
    return tickers, "nasdaqtrader.com (NYSE, Nasdaq, NYSE American ; hors ETF, warrants, préférentielles)"


def build_universe(settings: dict, log=print) -> dict:
    """Retourne {'tickers': [...], 'sources': {region: source}, 'by_region': {region: n}}."""
    regions = settings.get("regions", ["USA", "Europe"])
    tickers: list[str] = []
    sources = {}
    if "USA" in regions:
        if settings.get("us_mode", "complet") == "complet":
            us, src = us_full_universe(log)
        else:
            us, src = read_list_file("usa_rapide.txt"), "liste intégrée (mode rapide)"
        tickers += us
        sources["USA"] = src
    if "Europe" in regions:
        tickers += read_list_file("europe.txt")
        sources["Europe"] = "liste intégrée des principales valeurs (univers/europe.txt) — pas la cote complète"
    if "Autres" in regions:
        tickers += read_list_file("autres.txt")
        sources["Autres"] = "liste intégrée Canada/Japon/Australie/Hong Kong (univers/autres.txt)"
    perso = read_list_file("perso.txt")
    if perso:
        tickers += perso
        sources["Perso"] = "univers/perso.txt"
    tickers = list(dict.fromkeys(tickers))
    by_region: dict[str, int] = {}
    for t in tickers:
        by_region[region_of(t)] = by_region.get(region_of(t), 0) + 1
    return {"tickers": tickers, "sources": sources, "by_region": by_region}
