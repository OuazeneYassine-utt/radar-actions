"""Journal des signaux : enregistrement, suivi automatique et statistiques par catégorie."""
from __future__ import annotations

import uuid
from datetime import datetime

import numpy as np
import pandas as pd

from .config import JOURNAL_FILE, CATEGORY_LABELS

COLUMNS = ["id", "date_signal", "ticker", "nom", "place", "devise", "categorie", "score", "entree",
           "stop", "objectif1", "objectif2", "rr", "stop_temporel_seances", "prochain_evenement",
           "statut", "date_entree", "prix_entree", "date_sortie", "prix_sortie", "resultat_R",
           "perf_pct", "notes"]

OPEN_STATUSES = ("en attente de déclenchement", "en cours")


def load() -> pd.DataFrame:
    if JOURNAL_FILE.exists():
        df = pd.read_csv(JOURNAL_FILE, sep=";", dtype=str, keep_default_na=False)
        for c in COLUMNS:
            if c not in df.columns:
                df[c] = ""
        return df[COLUMNS]
    return pd.DataFrame(columns=COLUMNS)


def save(df: pd.DataFrame):
    df[COLUMNS].to_csv(JOURNAL_FILE, sep=";", index=False, encoding="utf-8-sig")


def add(rows: list[dict], scan_date: str) -> int:
    df = load()
    existing = set(zip(df["ticker"], df["date_signal"]))
    new = []
    for r in rows:
        if (r["ticker"], scan_date) in existing:
            continue
        new.append({
            "id": uuid.uuid4().hex[:8], "date_signal": scan_date, "ticker": r["ticker"],
            "nom": r.get("name") or "", "place": r.get("market") or "", "devise": r.get("currency") or "",
            "categorie": r["category"], "score": f"{r['prescore']:.1f}",
            "entree": f"{r['entry']:.4f}", "stop": f"{r['stop']:.4f}", "objectif1": f"{r['target1']:.4f}",
            "objectif2": f"{r['target2']:.4f}" if r.get("target2") else "",
            "rr": f"{r['rr']:.2f}", "stop_temporel_seances": str(r["time_stop"]),
            "prochain_evenement": r.get("earnings_date") or "", "statut": "en attente de déclenchement",
            "date_entree": "", "prix_entree": "", "date_sortie": "", "prix_sortie": "",
            "resultat_R": "", "perf_pct": "", "notes": "",
        })
    if new:
        df = pd.concat([df, pd.DataFrame(new)], ignore_index=True)
        save(df)
    return len(new)


def _num(x):
    try:
        return float(x)
    except Exception:
        return np.nan


def evaluate(row: dict, px: pd.DataFrame, expiry_sessions: int = 10) -> dict:
    """Rejoue le plan sur les cours postérieurs au signal (hypothèses prudentes)."""
    entry, stop, t1 = _num(row["entree"]), _num(row["stop"]), _num(row["objectif1"])
    tstop = int(_num(row["stop_temporel_seances"]) or 15)
    risk = entry - stop
    after = px[px.index > pd.Timestamp(row["date_signal"])].dropna(subset=["Close"])
    out = dict(row)
    if not np.isfinite(risk) or risk <= 0 or after.empty:
        return out
    fill_i, fill_px = None, None
    for i, (d, b) in enumerate(after.iterrows()):
        if i >= expiry_sessions:
            break
        if b["Open"] >= entry:
            fill_i, fill_px = i, float(b["Open"])  # ouverture au-dessus : exécution à l'ouverture
            break
        if b["High"] >= entry:
            fill_i, fill_px = i, entry
            break
    if fill_i is None:
        if len(after) >= expiry_sessions:
            out["statut"] = "expiré (non déclenché)"
        return out
    out["date_entree"] = after.index[fill_i].strftime("%Y-%m-%d")
    out["prix_entree"] = f"{fill_px:.4f}"
    status, exit_d, exit_px = "en cours", "", ""
    held = after.iloc[fill_i:]
    for j, (d, b) in enumerate(held.iterrows()):
        lo, hi, op = float(b["Low"]), float(b["High"]), float(b["Open"])
        if lo <= stop:  # prudent : si stop et objectif le même jour, on retient le stop
            exit_px = min(op, stop) if j > 0 else stop
            status, exit_d = "stoppé", d
            break
        if hi >= t1:
            exit_px = max(op, t1) if j > 0 else t1
            status, exit_d = "objectif atteint", d
            break
        if j + 1 >= tstop:
            exit_px, status, exit_d = float(b["Close"]), "sorti au temps", d
            break
    if status == "en cours":
        last = float(held["Close"].iloc[-1])
        out["resultat_R"] = f"{(last - fill_px) / risk:.2f}"
        out["perf_pct"] = f"{(last / fill_px - 1) * 100:.2f}"
    else:
        out["date_sortie"] = exit_d.strftime("%Y-%m-%d")
        out["prix_sortie"] = f"{exit_px:.4f}"
        out["resultat_R"] = f"{(exit_px - fill_px) / risk:.2f}"
        out["perf_pct"] = f"{(exit_px / fill_px - 1) * 100:.2f}"
    out["statut"] = status
    return out


def update(price_lookup) -> tuple[pd.DataFrame, list[str]]:
    """price_lookup(tickers) -> dict ticker -> DataFrame OHLC. Met à jour les lignes ouvertes."""
    df = load()
    if df.empty:
        return df, []
    open_mask = df["statut"].isin(OPEN_STATUSES)
    tickers = sorted(set(df.loc[open_mask, "ticker"]))
    prices = price_lookup(tickers) if tickers else {}
    missing = []
    for i in df.index[open_mask]:
        t = df.at[i, "ticker"]
        px = prices.get(t)
        if px is None:
            missing.append(t)
            continue
        new = evaluate(df.loc[i].to_dict(), px)
        for k, v in new.items():
            df.at[i, k] = v
    save(df)
    return df, missing


def stats(df: pd.DataFrame) -> dict:
    if df.empty:
        return {"by_category": [], "total": {}}
    d = df.copy()
    d["R"] = pd.to_numeric(d["resultat_R"], errors="coerce")
    closed = d[d["statut"].isin(["stoppé", "objectif atteint", "sorti au temps"])]
    out = []
    for cat in ["A", "B", "C", "D"]:
        g = d[d["categorie"] == cat]
        c = closed[closed["categorie"] == cat]
        out.append({
            "categorie": cat, "libelle": CATEGORY_LABELS[cat], "signaux": int(len(g)),
            "declenches": int(g["date_entree"].astype(bool).sum()), "clotures": int(len(c)),
            "taux_reussite": float((c["R"] > 0).mean()) if len(c) else None,
            "R_moyen": float(c["R"].mean()) if len(c) else None,
            "R_total": float(c["R"].sum()) if len(c) else None,
        })
    return {"by_category": out, "total": {
        "signaux": int(len(d)), "clotures": int(len(closed)),
        "taux_reussite": float((closed["R"] > 0).mean()) if len(closed) else None,
        "R_moyen": float(closed["R"].mean()) if len(closed) else None,
        "en_cours": int((d["statut"] == "en cours").sum()),
        "en_attente": int((d["statut"] == "en attente de déclenchement").sum()),
    }}


def delete(entry_id: str):
    df = load()
    df = df[df["id"] != entry_id]
    save(df)
