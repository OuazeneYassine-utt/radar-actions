"""Exports : fichier CSV pour l'étape IA (mode A) et prompt pré-rempli."""
from __future__ import annotations

from pathlib import Path

import pandas as pd

from .config import EXPORT_DIR

TEMPLATE = Path(__file__).with_name("prompt_template.txt")

CSV_COLUMNS = [
    ("selection", "selection"), ("ticker", "ticker"), ("name", "nom"), ("market", "place"),
    ("currency", "devise"), ("date", "date_cours"), ("close", "cours"), ("category", "categorie"),
    ("category_label", "setup"), ("status", "statut_setup"), ("prescore", "pre_score"),
    ("score_setup", "score_setup_40"), ("signal_notes", "signaux"), ("entry", "entree"),
    ("entry_note", "condition_entree"), ("stop", "stop"), ("stop_basis", "base_stop"),
    ("target1", "objectif1"), ("target1_basis", "base_objectif1"), ("target2", "objectif2"),
    ("rr", "rr"), ("potential_pct", "potentiel_pct"), ("risk_pct", "risque_pct"),
    ("time_stop", "stop_temporel_seances"), ("support", "support"), ("support_type", "type_support"),
    ("resistance", "resistance"), ("resistance_type", "type_resistance"),
    ("ret_1d", "perf_1j"), ("ret_5d", "perf_5j"), ("ret_1m", "perf_1m"), ("ret_3m", "perf_3m"),
    ("ret_6m", "perf_6m"), ("ret_ytd", "perf_ytd"), ("ret_1y", "perf_1a"), ("dist_high52", "dist_plus_haut_52s"),
    ("rsi", "rsi14"), ("atr", "atr14"), ("atr_pct", "atr_pct"), ("adx", "adx14"), ("macd_hist", "macd_hist"),
    ("relvol", "volume_relatif"), ("ma20", "ma20"), ("ma50", "ma50"), ("ma200", "ma200"), ("ema20", "ema20"),
    ("adv_usd", "volume_moyen_20j_usd"), ("benchmark", "indice_ref"), ("rs_1m", "rs_indice_1m"),
    ("rs_3m", "rs_indice_3m"), ("rs_6m", "rs_indice_6m"), ("p_rs_3m", "percentile_rs_3m"),
    ("p_rs_6m", "percentile_rs_6m"), ("rs_sector_1m", "rs_secteur_1m"), ("rs_sector_3m", "rs_secteur_3m"),
    ("rs_sector_6m", "rs_secteur_6m"), ("sector", "secteur"), ("industry", "industrie"),
    ("market_cap_usd", "capitalisation_usd"), ("forward_pe", "pe_prospectif"), ("trailing_pe", "pe_historique"),
    ("ev_ebitda", "ev_ebitda"), ("revenue_growth", "croissance_ca"), ("profit_margin", "marge_nette"),
    ("short_pct_float", "short_pct_flottant"), ("reco_mean", "reco_moyenne_1a5"), ("n_analysts", "nb_analystes"),
    ("earnings_date", "prochains_resultats"), ("days_to_earnings", "jours_avant_resultats"),
    ("ex_dividend_date", "ex_dividende"), ("position_shares", "taille_titres"),
    ("position_eur", "taille_eur"), ("flags", "alertes"), ("not_retained_reasons", "raisons_non_retenu"),
]


def _rows(scan: dict) -> list[dict]:
    out = []
    seen = set()
    for sel, lst in (("RETENU", scan.get("retained", [])), ("WATCHLIST", scan.get("watchlist", []))):
        for r in lst:
            if r["ticker"] in seen:
                continue
            seen.add(r["ticker"])
            row = {}
            for key, col in CSV_COLUMNS:
                if key == "selection":
                    v = sel
                elif key == "score_setup":
                    v = (r.get("score_parts") or {}).get("setup")
                else:
                    v = r.get(key)
                if isinstance(v, list):
                    v = " | ".join(str(x) for x in v)
                row[col] = v
            out.append(row)
    return out


def scan_csv(scan: dict) -> tuple[str, str]:
    """Retourne (nom de fichier, contenu CSV ; séparateur ;)."""
    date = (scan["meta"]["finished"] or "")[:10]
    name = f"radar_{date}.csv"
    df = pd.DataFrame(_rows(scan), columns=[c for _, c in CSV_COLUMNS])
    corr = scan.get("correlations") or []
    txt = df.to_csv(sep=";", index=False, float_format="%.4f")
    if corr:
        txt += "\n# correlations (60 séances) > 0,7 : " + ", ".join(
            f"{c['a']}/{c['b']} {c['corr']:.2f}" for c in corr) + "\n"
    (EXPORT_DIR / name).write_text(txt, encoding="utf-8-sig")
    return name, txt


def prompt_text(scan: dict) -> str:
    meta, reg, cov = scan["meta"], scan["regime"], scan["coverage"]
    csv_name = f"radar_{(meta['finished'] or '')[:10]}.csv"
    limits = []
    for region, src in cov["universe_sources"].items():
        limits.append(f"{region} : {src}")
    if cov["no_data"]:
        limits.append(f"{cov['no_data']} titres sans données téléchargeables")
    if meta.get("fx_estimated"):
        limits.append("taux de change estimés pour " + ", ".join(meta["fx_estimated"]))
    if meta.get("demo"):
        limits.insert(0, "ATTENTION : DONNÉES SIMULÉES (mode démo), ne pas utiliser pour investir")
    limits.append("fondamentaux du fichier = ratios de base Yahoo Finance, à vérifier")
    if cov["partial"]:
        limits.insert(0, "Le scan n'a couvert qu'une partie de l'univers disponible")
    last = ", ".join(f"{k} {v}" for k, v in sorted(meta["last_sessions"].items()))
    st = meta["settings"]
    return TEMPLATE.read_text(encoding="utf-8").format(
        csv_name=csv_name, scan_date=meta["started_label"], provider=meta["provider"],
        last_sessions=last or "n.d.", regime=reg["regime"], regime_reasons="; ".join(reg["reasons"]),
        pipeline=scan["pipeline"], coverage_limits="; ".join(limits) + ".", min_rr=meta["min_rr"],
        capital=f"{st['capital_eur']:.0f}", risk_pct=st["risk_pct"])
