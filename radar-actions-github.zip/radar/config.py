"""Paramètres par défaut du radar (modifiables dans l'interface, onglet Paramètres)."""
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
CACHE_DIR = DATA_DIR / "cache"
SCANS_DIR = DATA_DIR / "scans"
EXPORT_DIR = DATA_DIR / "exports"
UNIVERSE_DIR = BASE_DIR / "univers"
JOURNAL_FILE = DATA_DIR / "journal.csv"
SETTINGS_FILE = DATA_DIR / "parametres.json"

for _d in (DATA_DIR, CACHE_DIR, SCANS_DIR, EXPORT_DIR, UNIVERSE_DIR):
    _d.mkdir(parents=True, exist_ok=True)

DEFAULT_SETTINGS = {
    # Univers
    "regions": ["USA", "Europe"],          # USA, Europe, Autres
    "us_mode": "complet",                  # complet (NYSE/Nasdaq/AMEX) ou rapide (liste intégrée)
    # Filtres d'exclusion
    "min_mcap_usd": 500e6,
    "min_price_usd": 3.0,
    "min_adv_usd_us": 5e6,                 # volume moyen 20 j en valeur, USA
    "min_adv_usd_other": 2.2e6,            # ~2 M€ pour les autres places
    "min_history_days": 210,
    # Sélection
    "preselect_n": 60,                     # nombre de titres enrichis (capitalisation, secteur, résultats)
    "min_prescore_retain": 55,
    "min_prescore_watch": 45,
    "min_rr": 2.0,
    "min_rr_bear": 3.0,
    "max_retained": 10,
    "max_retained_bear": 5,
    "max_per_sector": 2,
    "earnings_warning_days": 14,           # ~10 séances
    # Gestion du risque (taille de position indicative)
    "capital_eur": 10000.0,
    "risk_pct": 0.75,
    # Téléchargement
    "chunk_size": 150,
    "pause_s": 1.0,
}

# Stops temporels en séances (horizon 2 à 12 semaines)
TIME_STOP = {"A": 30, "B": 15, "C": 15, "D": 30}

CATEGORY_LABELS = {
    "A": "Sur-réaction / correction",
    "B": "Rebond sur support",
    "C": "Breakout",
    "D": "Momentum / continuation",
}

# Devise par suffixe Yahoo
SUFFIX_CURRENCY = {
    "": "USD", "PA": "EUR", "AS": "EUR", "BR": "EUR", "MI": "EUR", "LS": "EUR", "DE": "EUR",
    "F": "EUR", "MC": "EUR", "HE": "EUR", "VI": "EUR", "IR": "EUR", "L": "GBp", "SW": "CHF",
    "ST": "SEK", "CO": "DKK", "OL": "NOK", "TO": "CAD", "T": "JPY", "AX": "AUD", "HK": "HKD",
}

SUFFIX_MARKET = {
    "": "USA", "PA": "Paris", "AS": "Amsterdam", "BR": "Bruxelles", "MI": "Milan", "LS": "Lisbonne",
    "DE": "Xetra", "F": "Francfort", "MC": "Madrid", "HE": "Helsinki", "VI": "Vienne", "IR": "Dublin",
    "L": "Londres", "SW": "SIX", "ST": "Stockholm", "CO": "Copenhague", "OL": "Oslo",
    "TO": "Toronto", "T": "Tokyo", "AX": "Australie", "HK": "Hong Kong",
}

SUFFIX_REGION = {s: ("USA" if s == "" else ("Autres" if s in ("TO", "T", "AX", "HK") else "Europe"))
                 for s in SUFFIX_MARKET}

# Indice de référence local pour la force relative
SUFFIX_BENCHMARK = {
    "": "^GSPC", "PA": "^FCHI", "AS": "^AEX", "BR": "^BFX", "MI": "FTSEMIB.MI", "LS": "PSI20.LS",
    "DE": "^GDAXI", "F": "^GDAXI", "MC": "^IBEX", "HE": "^OMXH25", "VI": "^ATX", "IR": "^ISEQ",
    "L": "^FTSE", "SW": "^SSMI", "ST": "^OMX", "CO": "^OMXC25", "OL": "OBX.OL",
    "TO": "^GSPTSE", "T": "^N225", "AX": "^AXJO", "HK": "^HSI",
}
EUROPE_FALLBACK_BENCHMARK = "^STOXX"

# Indices du régime de marché
REGIME_INDICES = {
    "^GSPC": "S&P 500", "^NDX": "Nasdaq 100", "^RUT": "Russell 2000", "^STOXX": "STOXX 600",
}
REGIME_EXTRA = {"^VIX": "VIX", "^TNX": "Taux 10 ans US (x10)"}

# ETF sectoriels US (force relative secteur pour les titres US)
US_SECTOR_ETF = {
    "Technology": "XLK", "Financial Services": "XLF", "Healthcare": "XLV",
    "Consumer Cyclical": "XLY", "Consumer Defensive": "XLP", "Energy": "XLE",
    "Industrials": "XLI", "Basic Materials": "XLB", "Utilities": "XLU",
    "Real Estate": "XLRE", "Communication Services": "XLC",
}

# Paires de change : (ticker Yahoo, inversé ?) -> USD par unité de devise
FX_TICKERS = {
    "EUR": ("EURUSD=X", False), "GBP": ("GBPUSD=X", False), "AUD": ("AUDUSD=X", False),
    "CHF": ("CHF=X", True), "SEK": ("SEK=X", True), "DKK": ("DKK=X", True), "NOK": ("NOK=X", True),
    "CAD": ("CAD=X", True), "JPY": ("JPY=X", True), "HKD": ("HKD=X", True),
}
# Valeurs de secours approximatives (utilisées seulement si le téléchargement échoue, signalé comme estimation)
FX_FALLBACK = {"USD": 1.0, "EUR": 1.17, "GBP": 1.34, "CHF": 1.25, "SEK": 0.106, "DKK": 0.157,
               "NOK": 0.10, "CAD": 0.72, "JPY": 0.0068, "AUD": 0.66, "HKD": 0.128}

HOST = "127.0.0.1"
PORT = 8765
