"""Indicateurs techniques calculés de façon vectorisée (une colonne par titre)."""
from __future__ import annotations

import numpy as np
import pandas as pd

from .universe import suffix_of

FIELDS = ["Open", "High", "Low", "Close", "Volume"]


def build_group_panels(prices: dict[str, pd.DataFrame], tickers: list[str]) -> dict[str, pd.DataFrame]:
    """Panneaux larges (dates x titres) pour un groupe partageant le même calendrier."""
    panels = {}
    for f in FIELDS:
        cols = {t: prices[t][f] for t in tickers if t in prices and f in prices[t]}
        panels[f] = pd.DataFrame(cols).sort_index()
    close = panels["Close"]
    if close.empty:
        return panels
    # retire les jours fériés du groupe (moins de 40 % des titres cotés)
    valid_rows = close.notna().mean(axis=1) >= 0.4
    for f in FIELDS:
        panels[f] = panels[f].loc[valid_rows]
    # dernière cotation réelle par titre (avant remplissage)
    panels["_last_real"] = panels["Close"].apply(lambda s: s.last_valid_index())
    for f in ["Open", "High", "Low", "Close"]:
        panels[f] = panels[f].ffill(limit=3)
    panels["Volume"] = panels["Volume"].fillna(0)
    return panels


def group_by_calendar(tickers: list[str]) -> dict[str, list[str]]:
    groups: dict[str, list[str]] = {}
    for t in tickers:
        groups.setdefault(suffix_of(t) or "US", []).append(t)
    return groups


def wilder(x: pd.DataFrame, n: int) -> pd.DataFrame:
    return x.ewm(alpha=1 / n, adjust=False, min_periods=n).mean()


def compute_wide(p: dict[str, pd.DataFrame]) -> dict[str, pd.DataFrame]:
    O, H, L, C, V = (p[f] for f in FIELDS)
    prevC = C.shift(1)
    tr = np.fmax(np.fmax(H - L, (H - prevC).abs()), (L - prevC).abs())
    atr = wilder(tr, 14)
    d = C.diff()
    up = wilder(d.clip(lower=0), 14)
    dn = wilder((-d).clip(lower=0), 14)
    rsi = 100 - 100 / (1 + up / dn.replace(0, np.nan))
    rsi = rsi.where(dn != 0, 100)
    ma = {n: C.rolling(n, min_periods=n).mean() for n in (20, 50, 100, 200)}
    ema20 = C.ewm(span=20, adjust=False, min_periods=20).mean()
    ema50 = C.ewm(span=50, adjust=False, min_periods=50).mean()
    ema12 = C.ewm(span=12, adjust=False, min_periods=12).mean()
    ema26 = C.ewm(span=26, adjust=False, min_periods=26).mean()
    macd = ema12 - ema26
    macd_sig = macd.ewm(span=9, adjust=False, min_periods=9).mean()
    std20 = C.rolling(20, min_periods=20).std()
    bbw = 4 * std20 / ma[20]
    bbw_rank = bbw.rolling(126, min_periods=60).rank(pct=True)
    upm = H.diff()
    dnm = -L.diff()
    pdm = upm.where((upm > dnm) & (upm > 0), 0.0)
    mdm = dnm.where((dnm > upm) & (dnm > 0), 0.0)
    pdi = 100 * wilder(pdm, 14) / atr
    mdi = 100 * wilder(mdm, 14) / atr
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, np.nan)
    adx = wilder(dx, 14)
    obv = (np.sign(d).fillna(0) * V).cumsum()
    vavg20 = V.rolling(20, min_periods=15).mean()
    relvol = V / vavg20.shift(1)
    move_atr = (C - prevC) / atr.shift(1)
    gap = O / prevC - 1
    return dict(atr=atr, rsi=rsi, ma20=ma[20], ma50=ma[50], ma100=ma[100], ma200=ma[200],
                ema20=ema20, ema50=ema50, macd=macd, macd_sig=macd_sig, bbw=bbw, bbw_rank=bbw_rank,
                adx=adx, pdi=pdi, mdi=mdi, obv=obv, vavg20=vavg20, relvol=relvol,
                move_atr=move_atr, gap=gap)


def _last(df: pd.DataFrame) -> pd.Series:
    return df.iloc[-1] if len(df) else pd.Series(dtype=float)


def _ret(C: pd.DataFrame, n: int) -> pd.Series:
    if len(C) <= n:
        return pd.Series(np.nan, index=C.columns)
    return C.iloc[-1] / C.iloc[-1 - n] - 1


def latest_metrics(p: dict[str, pd.DataFrame], w: dict[str, pd.DataFrame]) -> pd.DataFrame:
    O, H, L, C, V = (p[f] for f in FIELDS)
    if C.empty:
        return pd.DataFrame()
    last_date = C.index[-1]
    m = pd.DataFrame(index=C.columns)
    m["date"] = last_date.strftime("%Y-%m-%d")
    m["last_real"] = p["_last_real"].reindex(C.columns).astype(str).str[:10]
    m["n_obs"] = C.notna().sum()
    m["close"] = _last(C)
    m["open"] = _last(O)
    m["high"] = _last(H)
    m["low"] = _last(L)
    m["prev_close"] = C.iloc[-2] if len(C) > 1 else np.nan
    for n, k in [(1, "ret_1d"), (5, "ret_5d"), (21, "ret_1m"), (63, "ret_3m"), (126, "ret_6m"), (252, "ret_1y")]:
        m[k] = _ret(C, n)
    prev_year = C[C.index.year < last_date.year]
    m["ret_ytd"] = (C.iloc[-1] / prev_year.iloc[-1] - 1) if len(prev_year) else np.nan
    for k in ["ma20", "ma50", "ma100", "ma200", "ema20", "ema50", "rsi", "atr", "macd", "macd_sig",
              "bbw", "bbw_rank", "adx", "pdi", "mdi", "vavg20", "relvol"]:
        m[k] = _last(w[k])
    m["atr_pct"] = m["atr"] / m["close"]
    m["macd_hist"] = m["macd"] - m["macd_sig"]
    m["volume"] = _last(V)
    m["vavg50"] = V.iloc[-50:].mean()
    m["vol5_vs_20"] = V.iloc[-5:].mean() / V.iloc[-20:].mean().replace(0, np.nan)
    m["relvol_max5"] = w["relvol"].iloc[-5:].max()
    m["min_move_atr_5"] = w["move_atr"].iloc[-5:].min()
    m["max_move_atr_3"] = w["move_atr"].iloc[-3:].max()
    m["min_gap_5"] = w["gap"].iloc[-5:].min()
    m["bbw_rank_min15"] = w["bbw_rank"].iloc[-15:].min()
    m["rsi_min5"] = w["rsi"].iloc[-5:].min()
    m["ma200_slope"] = w["ma200"].iloc[-1] / w["ma200"].iloc[-21] - 1 if len(C) > 21 else np.nan
    obv = w["obv"]
    denom = (w["vavg20"].iloc[-1] * 20).replace(0, np.nan)
    m["obv_slope20"] = (obv.iloc[-1] - obv.iloc[-21]) / denom if len(C) > 21 else np.nan
    m["obv_slope60"] = (obv.iloc[-1] - obv.iloc[-61]) / (denom * 3) if len(C) > 61 else np.nan
    for n in (20, 50, 252):
        m[f"high{n}"] = H.iloc[-n:].max()
        m[f"low{n}"] = L.iloc[-n:].min()
    m["prior_high50"] = H.iloc[-54:-4].max() if len(C) > 54 else np.nan  # plus haut 50 j avant les 4 dernières séances
    m["prior_high252"] = H.iloc[-256:-4].max() if len(C) > 60 else np.nan
    m["dist_high52"] = m["close"] / m["high252"] - 1
    m["dist_low52"] = m["close"] / m["low252"] - 1
    m["dd_20"] = m["close"] / m["high20"] - 1
    m["dist_ma50"] = m["close"] / m["ma50"] - 1
    m["dist_ma200"] = m["close"] / m["ma200"] - 1
    m["dist_ema20"] = m["close"] / m["ema20"] - 1
    return m
