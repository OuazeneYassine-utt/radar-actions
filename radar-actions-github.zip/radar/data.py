"""Accès aux données de marché (Yahoo Finance via yfinance), cache et devises.

Un fournisseur « démo » à données simulées existe pour tester l'application hors ligne
(variable d'environnement RADAR_DEMO=1). Il est signalé partout comme tel.
"""
from __future__ import annotations

import os
import pickle
import time
import zlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd

from .config import CACHE_DIR, FX_TICKERS, FX_FALLBACK, SUFFIX_CURRENCY
from .universe import suffix_of

FIELDS = ["Open", "High", "Low", "Close", "Volume"]
DEMO = os.environ.get("RADAR_DEMO") == "1"


def currency_of(ticker: str) -> str:
    return SUFFIX_CURRENCY.get(suffix_of(ticker), "USD")


# ---------------------------------------------------------------------------
# Fournisseur Yahoo Finance
# ---------------------------------------------------------------------------
class YahooProvider:
    name = "Yahoo Finance (yfinance)"

    def __init__(self):
        import yfinance as yf  # import tardif : message clair si absent
        self.yf = yf

    def _split(self, df: pd.DataFrame, chunk: list[str]) -> dict[str, pd.DataFrame]:
        out = {}
        if df is None or df.empty:
            return out
        if isinstance(df.columns, pd.MultiIndex):
            lvl0 = set(df.columns.get_level_values(0))
            for t in chunk:
                if t in lvl0:
                    sub = df[t]
                elif t in set(df.columns.get_level_values(1)):
                    sub = df.xs(t, axis=1, level=1)
                else:
                    continue
                sub = sub[[c for c in FIELDS if c in sub.columns]].dropna(how="all")
                if len(sub) and "Close" in sub and sub["Close"].notna().sum() > 0:
                    out[t] = sub
        elif len(chunk) == 1:
            sub = df[[c for c in FIELDS if c in df.columns]].dropna(how="all")
            if len(sub):
                out[chunk[0]] = sub
        return out

    def download(self, tickers: list[str], start: str, chunk_size=150, pause_s=1.0,
                 progress=None, log=print) -> dict[str, pd.DataFrame]:
        result: dict[str, pd.DataFrame] = {}
        chunks = [tickers[i:i + chunk_size] for i in range(0, len(tickers), chunk_size)]
        for k, chunk in enumerate(chunks):
            for attempt in range(3):
                try:
                    df = self.yf.download(chunk, start=start, interval="1d", auto_adjust=True,
                                          group_by="ticker", threads=True, progress=False)
                    got = self._split(df, chunk)
                    result.update(got)
                    break
                except Exception as exc:
                    wait = 5 * (attempt + 1)
                    log(f"Lot {k + 1}/{len(chunks)} : erreur ({str(exc)[:120]}), nouvel essai dans {wait} s")
                    time.sleep(wait)
            if progress:
                progress(k + 1, len(chunks))
            time.sleep(pause_s)
        # Deuxième passe pour les manquants (souvent des limites de débit ponctuelles)
        missing = [t for t in tickers if t not in result]
        if missing and len(missing) < len(tickers):
            log(f"Nouvel essai pour {len(missing)} titres sans données…")
            for i in range(0, len(missing), chunk_size):
                chunk = missing[i:i + chunk_size]
                try:
                    df = self.yf.download(chunk, start=start, interval="1d", auto_adjust=True,
                                          group_by="ticker", threads=True, progress=False)
                    result.update(self._split(df, chunk))
                except Exception:
                    pass
                time.sleep(pause_s)
        return result

    def info(self, ticker: str) -> dict:
        tk = self.yf.Ticker(ticker)
        raw = {}
        try:
            raw = tk.info or {}
        except Exception:
            raw = {}
        info = normalize_info(raw)
        if not info.get("earnings_date"):
            try:
                cal = tk.calendar
                dates = cal.get("Earnings Date") if isinstance(cal, dict) else None
                if dates:
                    future = [pd.Timestamp(d) for d in dates if pd.Timestamp(d) >= pd.Timestamp.now().normalize()]
                    if future:
                        info["earnings_date"] = min(future).strftime("%Y-%m-%d")
            except Exception:
                pass
        return info


def _ts_to_date(v):
    try:
        if v is None:
            return None
        return datetime.fromtimestamp(int(v), tz=timezone.utc).strftime("%Y-%m-%d")
    except Exception:
        return None


def normalize_info(raw: dict) -> dict:
    today = datetime.now().strftime("%Y-%m-%d")
    earn = None
    for k in ("earningsTimestampStart", "earningsTimestamp", "earningsCallTimestampStart"):
        d = _ts_to_date(raw.get(k))
        if d and d >= today:
            earn = d
            break
    exdiv = _ts_to_date(raw.get("exDividendDate"))
    if exdiv and exdiv < today:
        exdiv = None
    return {
        "name": raw.get("shortName") or raw.get("longName"),
        "sector": raw.get("sector"),
        "industry": raw.get("industry"),
        "currency": raw.get("currency"),
        "market_cap": raw.get("marketCap"),
        "shares_out": raw.get("sharesOutstanding"),
        "trailing_pe": raw.get("trailingPE"),
        "forward_pe": raw.get("forwardPE"),
        "ev_ebitda": raw.get("enterpriseToEbitda"),
        "ev_revenue": raw.get("enterpriseToRevenue"),
        "price_to_book": raw.get("priceToBook"),
        "profit_margin": raw.get("profitMargins"),
        "revenue_growth": raw.get("revenueGrowth"),
        "earnings_growth": raw.get("earningsGrowth"),
        "roe": raw.get("returnOnEquity"),
        "debt_to_equity": raw.get("debtToEquity"),
        "fcf": raw.get("freeCashflow"),
        "short_pct_float": raw.get("shortPercentOfFloat"),
        "short_ratio": raw.get("shortRatio"),
        "insiders_pct": raw.get("heldPercentInsiders"),
        "reco_mean": raw.get("recommendationMean"),
        "n_analysts": raw.get("numberOfAnalystOpinions"),
        "target_mean": raw.get("targetMeanPrice"),
        "earnings_date": earn,
        "ex_dividend_date": exdiv,
        "quote_type": raw.get("quoteType"),
    }


# ---------------------------------------------------------------------------
# Fournisseur démo (données simulées, uniquement pour tester l'application)
# ---------------------------------------------------------------------------
class DemoProvider:
    name = "DÉMO — données simulées (aucune donnée réelle)"

    def __init__(self, seed=7):
        self.seed = seed

    def _series(self, ticker: str, dates: pd.DatetimeIndex) -> pd.DataFrame:
        rng = np.random.default_rng(zlib.crc32(ticker.encode()))
        n = len(dates)
        base = rng.uniform(8, 400)
        drift = rng.normal(0.0004, 0.0008)
        vol = rng.uniform(0.01, 0.035)
        rets = rng.normal(drift, vol, n)
        kind = rng.integers(0, 6)
        if kind == 0:   # correction récente brutale
            rets[-4] = -0.12
        elif kind == 1:  # base puis cassure
            rets[-60:-3] = rng.normal(0, vol / 3, 57)
            rets[-2] = 0.06
        elif kind == 2:  # tendance haussière + repli
            rets[:-8] += 0.002
            rets[-8:] = rng.normal(-0.006, vol / 2, 8)
        elif kind == 3:  # retour sur support
            rets[-30:] = rng.normal(-0.004, vol / 2, 30)
        close = base * np.exp(np.cumsum(rets))
        high = close * (1 + np.abs(rng.normal(0, vol / 2, n)))
        low = close * (1 - np.abs(rng.normal(0, vol / 2, n)))
        open_ = np.r_[close[0], close[:-1]] * (1 + rng.normal(0, vol / 4, n))
        high = np.maximum.reduce([high, open_, close])
        low = np.minimum.reduce([low, open_, close])
        v = rng.uniform(2e5, 6e6) * np.exp(rng.normal(0, 0.4, n))
        if kind == 1:
            v[-2] *= 3
        if kind == 0:
            v[-4] *= 4
        if currency_of(ticker) == "GBp":
            close, high, low, open_ = close * 10, high * 10, low * 10, open_ * 10
        return pd.DataFrame({"Open": open_, "High": high, "Low": low, "Close": close, "Volume": v}, index=dates)

    def download(self, tickers, start, chunk_size=150, pause_s=0.0, progress=None, log=print):
        end = pd.Timestamp.now().normalize() - pd.Timedelta(days=1)
        dates = pd.bdate_range(start=start, end=end)
        out = {}
        chunks = [tickers[i:i + chunk_size] for i in range(0, len(tickers), chunk_size)]
        for k, chunk in enumerate(chunks):
            for t in chunk:
                if t.startswith("^") or t.endswith("=X"):
                    df = self._series(t, dates)
                    if t.endswith("=X"):
                        cur = t[:3]
                        lvl = FX_FALLBACK.get(cur, 1.0)
                        lvl = (1 / lvl) if len(t) == 5 else lvl
                        df[["Open", "High", "Low", "Close"]] = lvl
                    out[t] = df
                elif zlib.crc32(t.encode()) % 23 != 0:  # ~4 % de titres « sans données »
                    out[t] = self._series(t, dates)
            if progress:
                progress(k + 1, len(chunks))
        return out

    def info(self, ticker):
        rng = np.random.default_rng(zlib.crc32((ticker + 'i').encode()))
        sectors = ["Technology", "Healthcare", "Industrials", "Financial Services", "Energy",
                   "Consumer Cyclical", "Basic Materials", "Utilities"]
        earn = (datetime.now() + timedelta(days=int(rng.integers(3, 80)))).strftime("%Y-%m-%d")
        return {"name": f"{ticker} (démo)", "sector": sectors[rng.integers(0, len(sectors))],
                "industry": "Démo", "market_cap": float(rng.uniform(2e8, 2e11)),
                "forward_pe": float(rng.uniform(8, 40)), "trailing_pe": float(rng.uniform(8, 50)),
                "ev_ebitda": float(rng.uniform(5, 25)), "short_pct_float": float(rng.uniform(0, 0.2)),
                "earnings_date": earn, "reco_mean": float(rng.uniform(1.5, 3.5)),
                "n_analysts": int(rng.integers(0, 30)), "revenue_growth": float(rng.normal(0.08, 0.1)),
                "profit_margin": float(rng.normal(0.12, 0.08))}


def get_provider():
    return DemoProvider() if DEMO else YahooProvider()


# ---------------------------------------------------------------------------
# Cache
# ---------------------------------------------------------------------------
def load_price_cache(max_age_h: float = 4.0) -> tuple[dict, datetime | None]:
    path = CACHE_DIR / "prix.pkl"
    if not path.exists():
        return {}, None
    mtime = datetime.fromtimestamp(path.stat().st_mtime)
    if datetime.now() - mtime > timedelta(hours=max_age_h):
        return {}, None
    if max_age_h < 24 and a_market_closed_since(mtime):
        return {}, None  # une place a clôturé depuis : les cours en cache sont périmés
    try:
        with open(path, "rb") as f:
            data = pickle.load(f)
        if data.get("demo") != DEMO:
            return {}, None
        return data.get("prices", {}), mtime
    except Exception:
        return {}, None


def save_price_cache(prices: dict):
    path = CACHE_DIR / "prix.pkl"
    with open(path, "wb") as f:
        pickle.dump({"prices": prices, "demo": DEMO, "saved": datetime.now()}, f)


def fetch_prices(provider, tickers, start, settings, use_cache=True, progress=None, log=print):
    """Télécharge les prix manquants (le cache de moins de 4 h est réutilisé)."""
    cached, when = load_price_cache() if use_cache else ({}, None)
    missing = [t for t in tickers if t not in cached]
    if when and not missing:
        log(f"Prix réutilisés depuis le cache ({when:%H:%M}).")
        if progress:
            progress(1, 1)
        return {t: cached[t] for t in tickers if t in cached}, when
    if when:
        log(f"Cache du {when:%H:%M} : {len(tickers) - len(missing)} titres réutilisés, {len(missing)} à télécharger.")
    got = provider.download(missing, start, chunk_size=settings.get("chunk_size", 150),
                            pause_s=0 if DEMO else settings.get("pause_s", 1.0),
                            progress=progress, log=log)
    trim_incomplete_sessions(got)  # le cache ne contient jamais de séance partielle
    merged = dict(cached)
    merged.update(got)
    save_price_cache(merged)
    return {t: merged[t] for t in tickers if t in merged}, datetime.now()


def fetch_infos(provider, tickers, max_workers=6, progress=None, log=print) -> dict:
    out = {}
    done = 0
    workers = 1 if DEMO else max_workers
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(provider.info, t): t for t in tickers}
        for fut in as_completed(futs):
            t = futs[fut]
            try:
                out[t] = fut.result()
            except Exception as exc:
                out[t] = {}
                log(f"Infos indisponibles pour {t} ({str(exc)[:80]})")
            done += 1
            if progress:
                progress(done, len(tickers))
    return out


# Heure de clôture locale par place (fuseau, heure, minute)
SESSION_CLOSE = {
    "": ("America/New_York", 16, 0), "TO": ("America/Toronto", 16, 0), "L": ("Europe/London", 16, 35),
    "T": ("Asia/Tokyo", 15, 30), "AX": ("Australia/Sydney", 16, 10), "HK": ("Asia/Hong_Kong", 16, 10),
}
EUROPE_CLOSE = ("Europe/Paris", 17, 40)


def _session_suffix(ticker: str) -> str | None:
    from .config import SUFFIX_BENCHMARK, EUROPE_FALLBACK_BENCHMARK
    if ticker.endswith("=X"):
        return None  # change : marché continu
    if ticker.startswith("^") or ticker.endswith(".MI") or ticker.endswith(".LS") or ticker.endswith(".OL"):
        for suf, b in SUFFIX_BENCHMARK.items():
            if b == ticker:
                return suf
        if ticker == EUROPE_FALLBACK_BENCHMARK:
            return "PA"
        if ticker.startswith("^"):
            return ""
    return suffix_of(ticker)


def a_market_closed_since(t_local_naive: datetime) -> bool:
    """Vrai si une place a clôturé entre l'instant donné (heure locale de la machine) et maintenant."""
    from zoneinfo import ZoneInfo
    since = t_local_naive.astimezone(timezone.utc)
    now = datetime.now(timezone.utc)
    for tz, h, mnt in list(SESSION_CLOSE.values()) + [EUROPE_CLOSE]:
        try:
            z = ZoneInfo(tz)
        except Exception:
            continue
        for back in (0, 1):
            day = (now.astimezone(z) - timedelta(days=back)).date()
            close = datetime(day.year, day.month, day.day, h, mnt, tzinfo=z).astimezone(timezone.utc)
            if since < close <= now:
                return True
    return False


def trim_incomplete_sessions(prices: dict) -> int:
    """Retire la barre du jour si la place n'a pas encore clôturé (données de séance partielles)."""
    from zoneinfo import ZoneInfo
    removed = 0
    now_utc = datetime.now(timezone.utc)
    cache = {}
    for t, df in list(prices.items()):
        suf = _session_suffix(t)
        if suf is None or df is None or df.empty:
            continue
        if suf not in cache:
            tz, h, mnt = SESSION_CLOSE.get(suf, EUROPE_CLOSE)
            try:
                local = now_utc.astimezone(ZoneInfo(tz))
            except Exception:
                cache[suf] = None
                continue
            closed = (local.hour, local.minute) >= (h, mnt)
            cache[suf] = (local.date(), closed)
        info = cache[suf]
        if info is None:
            continue
        today, closed = info
        last = pd.Timestamp(df.index[-1])
        if last.date() >= today and not closed:
            prices[t] = df.iloc[:-1]
            removed += 1
    return removed


def fx_to_usd(prices: dict) -> tuple[dict, list[str]]:
    """USD par unité de chaque devise. Retourne (taux, devises estimées faute de données)."""
    rates = {"USD": 1.0}
    estimated = []
    for cur, (tk, inverted) in FX_TICKERS.items():
        df = prices.get(tk)
        val = None
        if df is not None and len(df) and df["Close"].notna().any():
            last = float(df["Close"].dropna().iloc[-1])
            if last > 0:
                val = 1.0 / last if inverted else last
        if val is None:
            val = FX_FALLBACK[cur]
            estimated.append(cur)
        rates[cur] = val
    rates["GBp"] = rates["GBP"] / 100.0
    return rates, estimated
