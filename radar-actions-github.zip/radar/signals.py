"""Détection des setups A–D, supports/résistances, pré-score et plan de trade."""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .config import TIME_STOP, CATEGORY_LABELS


def _f(x, default=np.nan):
    try:
        x = float(x)
        return x if math.isfinite(x) else default
    except Exception:
        return default


# ---------------------------------------------------------------------------
# Pivots, zones, supports et résistances
# ---------------------------------------------------------------------------
def pivots(high: np.ndarray, low: np.ndarray, w: int = 5, lookback: int = 250):
    n = len(high)
    start = max(w, n - lookback)
    lows, highs = [], []
    for i in range(start, n - w):
        seg_l = low[i - w:i + w + 1]
        seg_h = high[i - w:i + w + 1]
        if np.isfinite(low[i]) and low[i] == np.nanmin(seg_l):
            lows.append((i, float(low[i])))
        if np.isfinite(high[i]) and high[i] == np.nanmax(seg_h):
            highs.append((i, float(high[i])))
    return lows, highs


def zones(points, price: float, atr: float):
    """Regroupe des pivots proches en zones (tolérance max(1 %, 0,5 ATR))."""
    if not points:
        return []
    tol = max(0.01 * price, 0.5 * atr if np.isfinite(atr) else 0)
    pts = sorted(points, key=lambda p: p[1])
    groups = [[pts[0]]]
    for p in pts[1:]:
        mean = np.mean([q[1] for q in groups[-1]])
        if abs(p[1] - mean) <= tol:
            groups[-1].append(p)
        else:
            groups.append([p])
    out = []
    for g in groups:
        out.append({"level": float(np.mean([q[1] for q in g])), "touches": len(g),
                    "last_idx": max(q[0] for q in g)})
    return out


def levels_for(df: pd.DataFrame, m: pd.Series):
    close, atr = _f(m["close"]), _f(m["atr"])
    H, L = df["High"].to_numpy(float), df["Low"].to_numpy(float)
    plows, phighs = pivots(H, L)
    sup, res = [], []
    for z in zones(plows, close, atr):
        if z["level"] <= close:
            strength = 4 if z["touches"] == 1 else min(10, 6 + 2 * (z["touches"] - 2))
            sup.append({"level": z["level"], "type": f"pivot bas ({z['touches']} contact{'s' if z['touches'] > 1 else ''})",
                        "touches": z["touches"], "strength": strength})
        else:
            res.append({"level": z["level"], "type": f"pivot haut ({z['touches']} contact{'s' if z['touches'] > 1 else ''})",
                        "touches": z["touches"]})
    for z in zones(phighs, close, atr):
        if z["level"] > close:
            res.append({"level": z["level"], "type": f"pivot haut ({z['touches']} contact{'s' if z['touches'] > 1 else ''})",
                        "touches": z["touches"]})
        else:
            sup.append({"level": z["level"], "type": "ancienne résistance", "touches": z["touches"],
                        "strength": 5 if z["touches"] >= 2 else 3})
    ma200, ma50 = _f(m["ma200"]), _f(m["ma50"])
    if np.isfinite(ma200):
        if ma200 <= close:
            sup.append({"level": ma200, "type": "MA200", "touches": 0,
                        "strength": 8 if _f(m["ma200_slope"], 0) > 0 else 5})
        else:
            res.append({"level": ma200, "type": "MA200", "touches": 0})
    if np.isfinite(ma50):
        if ma50 <= close:
            sup.append({"level": ma50, "type": "MA50", "touches": 0, "strength": 5})
        else:
            res.append({"level": ma50, "type": "MA50", "touches": 0})
    low52, high52 = _f(m["low252"]), _f(m["high252"])
    if np.isfinite(low52) and low52 <= close:
        sup.append({"level": low52, "type": "plus bas 52 s", "touches": 1, "strength": 6})
    if np.isfinite(high52) and high52 > close * 1.002:
        res.append({"level": high52, "type": "plus haut 52 s", "touches": 1})
    sup.sort(key=lambda s: -s["level"])
    res.sort(key=lambda r: r["level"])
    return sup, res


# ---------------------------------------------------------------------------
# Motifs
# ---------------------------------------------------------------------------
def bullish_divergence(df: pd.DataFrame, rsi: pd.Series) -> bool:
    if len(df) < 45:
        return False
    low = df["Low"].to_numpy(float)
    r = rsi.to_numpy(float)
    a = low[-40:-10]
    b = low[-10:]
    if not (np.isfinite(a).any() and np.isfinite(b).any()):
        return False
    i1 = int(np.nanargmin(a)) + len(low) - 40
    i2 = int(np.nanargmin(b)) + len(low) - 10
    return bool(low[i2] < low[i1] and np.isfinite(r[i1]) and np.isfinite(r[i2]) and r[i2] > r[i1] + 2)


def reversal_candle(df: pd.DataFrame) -> str | None:
    if len(df) < 3:
        return None
    for k in (-1, -2):
        o, h, l, c = (float(df[f].iloc[k]) for f in ("Open", "High", "Low", "Close"))
        po, pc = float(df["Open"].iloc[k - 1]), float(df["Close"].iloc[k - 1])
        rng = h - l
        if rng <= 0:
            continue
        body = abs(c - o)
        lower = min(o, c) - l
        if lower >= 2 * body and (c - l) / rng >= 0.66:
            return "marteau" if k == -1 else "marteau (veille)"
        if c > o and pc < po and c >= po and o <= pc:
            return "avalement haussier" if k == -1 else "avalement haussier (veille)"
    return None


def capitulation(df: pd.DataFrame, relvol: pd.Series) -> bool:
    if len(df) < 12:
        return False
    rv = relvol.iloc[-10:]
    down = (df["Close"].diff().iloc[-10:] < 0)
    return bool(((rv >= 2) & down).any())


def base_info(df: pd.DataFrame, level_lookback: int = 43):
    """Amplitude de la base (hors 3 dernières séances)."""
    if len(df) < level_lookback + 1:
        return None
    seg = df.iloc[-level_lookback:-3]
    hi, lo = float(seg["High"].max()), float(seg["Low"].min())
    seg20 = df.iloc[-23:-3]
    hi20, lo20 = float(seg20["High"].max()), float(seg20["Low"].min())
    return {"high": hi, "low": lo, "range40": hi / lo - 1, "range20": hi20 / lo20 - 1, "height": hi - lo}


# ---------------------------------------------------------------------------
# Catégories
# ---------------------------------------------------------------------------
def setup_A(m, df, rsi, relvol):
    mv, r20, gap = _f(m["min_move_atr_5"], 0), _f(m["ret_1m"], 0), _f(m["min_gap_5"], 0)
    if not (mv <= -2 or r20 <= -0.15 or gap <= -0.05):
        return None
    notes = []
    if mv <= -2:
        notes.append(f"baisse de {abs(mv):.1f} ATR en une séance (5 derniers jours)")
    if r20 <= -0.15:
        notes.append(f"{r20:.0%} sur 1 mois")
    if gap <= -0.05:
        notes.append(f"gap baissier de {gap:.0%}")
    mag = max(min(-mv, 5) / 5, min(-r20 / 0.30, 1), min(-gap / 0.12, 1))
    score = 12 * max(0, mag)
    close = _f(m["close"])
    low3 = float(df["Low"].iloc[-3:].min())
    if close > low3 and close >= _f(m["prev_close"]):
        score += 8
        notes.append("stabilisation (pas de nouveau plus bas, clôture en hausse)")
    rc = reversal_candle(df)
    if rc:
        score += 5
        notes.append(rc)
    if _f(m["rsi"], 50) > _f(m["rsi_min5"], 50) + 5:
        score += 5
        notes.append("RSI qui se redresse")
    if _f(m["dist_ma200"], -1) > 0:
        score += 10
        notes.append("toujours au-dessus de la MA200 (repli dans une tendance haussière)")
    elif _f(m["dist_ma200"], -1) > -0.10:
        score += 3
    # jour de l'événement et niveau d'avant-baisse
    mv_series = df["Close"].pct_change().iloc[-5:]
    ev = int(np.nanargmin(mv_series.to_numpy()))
    ev_pos = len(df) - 5 + ev
    pre_level = float(df["Close"].iloc[ev_pos - 1]) if ev_pos >= 1 else np.nan
    notes.append("cause de la baisse à identifier (étape actualités)")
    return {"cat": "A", "setup": min(40, score), "notes": notes, "pre_event_level": pre_level,
            "event_date": df.index[ev_pos].strftime("%Y-%m-%d")}


def setup_B(m, df, rsi, relvol, sup):
    close = _f(m["close"])
    # un rebond sur support suppose un repli préalable vers ce support
    if _f(m["dd_20"], 0) > -0.05:
        return None
    cands = [s for s in sup if 0 <= (close - s["level"]) / s["level"] <= 0.05
             and (s["touches"] >= 2 or s["type"] in ("MA200", "plus bas 52 s"))]
    if not cands:
        return None
    s = max(cands, key=lambda x: (x["strength"], x["level"]))
    dist = (close - s["level"]) / s["level"]
    notes = [f"à {dist:.1%} du support {s['type']} ({s['level']:.2f})"]
    score = (1 - dist / 0.05) * 10 + s["strength"]
    stab = 0
    if bullish_divergence(df, rsi):
        stab += 8
        notes.append("divergence haussière RSI")
    rc = reversal_candle(df)
    if rc:
        stab += 6
        notes.append(rc)
    if _f(m["vol5_vs_20"], 1) < 0.8:
        stab += 4
        notes.append("assèchement des volumes")
    if capitulation(df, relvol):
        stab += 4
        notes.append("volume de capitulation récent")
    score += min(stab, 20)
    return {"cat": "B", "setup": min(40, score), "notes": notes, "support": s}


def setup_C(m, df):
    close, atr = _f(m["close"]), _f(m["atr"])
    ph50, ph252 = _f(m["prior_high50"]), _f(m["prior_high252"])
    if not np.isfinite(ph50):
        return None
    base = base_info(df)
    if base is None:
        return None
    # cassure récente (3 dernières séances) ou proximité 0–3 %
    closes = df["Close"].iloc[-3:].to_numpy(float)
    rv = m["_relvol_last3"]
    broke = [i for i in range(3) if closes[i] > ph50]
    level = ph50
    is_52 = np.isfinite(ph252) and close > ph252
    near = 0 <= (ph50 - close) / ph50 <= 0.03
    if not broke and not near:
        return None
    base_ok = base["range40"] <= 0.25 and base["range20"] <= 0.15
    if not base_ok:
        return None
    notes = []
    score = 0
    if base["range20"] <= 0.10:
        score += 10
        notes.append(f"base serrée ({base['range20']:.0%} sur 20 j)")
    else:
        score += 6
        notes.append(f"base de {base['range40']:.0%} sur 40 j")
    if _f(m["bbw_rank_min15"], 1) <= 0.2:
        score += 8
        notes.append("compression des bandes de Bollinger")
    status = "déclenchement en attente"
    bo_rv = np.nan
    if broke:
        i = broke[0]
        bo_rv = float(rv[i]) if np.isfinite(rv[i]) else np.nan
        status = "cassure confirmée" if np.isfinite(bo_rv) and bo_rv >= 1.5 else "cassure sans volume"
        if np.isfinite(bo_rv) and bo_rv >= 2:
            score += 8
        elif np.isfinite(bo_rv) and bo_rv >= 1.5:
            score += 5
        notes.append(f"clôture au-dessus du plus haut 50 j ({level:.2f}), volume relatif {bo_rv:.1f}")
    else:
        notes.append(f"à {(ph50 - close) / ph50:.1%} sous le plus haut 50 j ({level:.2f})")
    score += 6 if is_52 else 3
    if is_52:
        notes.append("nouveau plus haut 52 semaines")
    if _f(m["ma50"]) > _f(m["ma200"]) and close > _f(m["ma200"]):
        score += 8
        notes.append("tendance de fond haussière (MA50 > MA200)")
    if broke and np.isfinite(atr) and close - level > 2 * atr:
        score -= 8
        notes.append("déjà étendu (> 2 ATR au-dessus du niveau cassé)")
    if not broke:
        score *= 0.8
    if status == "cassure sans volume":
        score *= 0.85
    return {"cat": "C", "setup": max(0, min(40, score)), "notes": notes, "level": level,
            "base": base, "status": status, "breakout_relvol": bo_rv}


def setup_D(m, df, p3, p6):
    close = _f(m["close"])
    ma50, ma200, ema20, adx = _f(m["ma50"]), _f(m["ma200"]), _f(m["ema20"]), _f(m["adx"], 0)
    if not (ma50 > ma200 and close > ma200 and adx >= 20 and p3 >= 0.67 and p6 >= 0.67):
        return None
    low3 = float(df["Low"].iloc[-3:].min())
    touch_ema = low3 <= ema20 * 1.01
    touch_ma50 = low3 <= ma50 * 1.01
    if not ((touch_ema or touch_ma50) and close >= ma50 * 0.99 and close <= ema20 * 1.03):
        return None
    notes = [f"force relative 3 m/6 m : percentiles {p3:.0%} / {p6:.0%}", f"ADX {adx:.0f}"]
    score = 15 * min(1, ((p3 + p6) / 2 - 0.67) / 0.33) + 8 * min(1, (adx - 20) / 20)
    if touch_ma50:
        score += 7
        notes.append("repli sur la MA50")
    else:
        score += 6
        notes.append("repli sur l'EMA20")
    if _f(m["vol5_vs_20"], 1) < 0.9:
        score += 5
        notes.append("repli sur volumes faibles")
    if 40 <= _f(m["rsi"], 0) <= 60:
        score += 4
    return {"cat": "D", "setup": min(40, score), "notes": notes}


# ---------------------------------------------------------------------------
# Plan de trade
# ---------------------------------------------------------------------------
def trade_plan(cat: str, s: dict, m: pd.Series, df: pd.DataFrame, sup: list, res: list) -> dict:
    close, atr = _f(m["close"]), _f(m["atr"])
    high_last = _f(m["high"])
    notes = []
    # Entrée
    if cat == "C":
        if s.get("status", "").startswith("cassure"):
            entry, entry_note = close, "au marché ou sur repli vers le niveau cassé"
        else:
            entry, entry_note = s["level"] * 1.002, "ordre d'achat au-dessus de la résistance (clôture + volume relatif > 1,5)"
    else:
        entry = max(close, high_last)
        entry_note = "au-dessus du plus haut de la dernière séance (confirmation)"
    # Stop technique
    if cat == "A":
        tech, basis = float(df["Low"].iloc[-5:].min()) - 0.25 * atr, "sous le plus bas des 5 dernières séances"
    elif cat == "B":
        tech, basis = s["support"]["level"] - 0.5 * atr, f"sous le support {s['support']['type']}"
    elif cat == "C":
        tech, basis = s["level"] - 1.0 * atr, "retour sous le niveau cassé (−1 ATR)"
    else:
        tech = min(float(df["Low"].iloc[-10:].min()) - 0.25 * atr, _f(m["ma50"]) - 0.5 * atr)
        basis = "sous le dernier creux / la MA50"
    dist_atr = (entry - tech) / atr if atr > 0 else np.nan
    if not np.isfinite(dist_atr) or dist_atr < 1.0:
        stop, basis = entry - 1.5 * atr, "1,5 ATR (stop technique trop serré)"
    elif dist_atr > 3.0:
        stop, basis = entry - 2.5 * atr, "2,5 ATR (support technique éloigné)"
    else:
        stop = tech
    risk = entry - stop
    # Résistances disponibles
    lv = [dict(r) for r in res]
    if cat == "A" and np.isfinite(s.get("pre_event_level", np.nan)):
        lv.append({"level": s["pre_event_level"], "type": "niveau d'avant-baisse", "touches": 0})
    lv = sorted([r for r in lv if r["level"] >= entry + 1.0 * atr], key=lambda r: r["level"])
    if lv:
        t1, t1_basis = lv[0]["level"], lv[0]["type"]
    elif cat == "C" and s.get("base"):
        t1, t1_basis = max(s["level"] + s["base"]["height"], entry + 2 * atr), "projection de la hauteur de base"
    else:
        t1, t1_basis = entry + 3 * atr, "projection 3 ATR (aucune résistance identifiée)"
    rest = [r for r in lv if r["level"] >= t1 + 0.5 * atr]
    t2, t2_basis = (rest[0]["level"], rest[0]["type"]) if rest else (np.nan, None)
    rr = (t1 - entry) / risk if risk > 0 else np.nan
    return {"entry": entry, "entry_note": entry_note, "stop": stop, "stop_basis": basis,
            "target1": t1, "target1_basis": t1_basis, "target2": t2, "target2_basis": t2_basis,
            "rr": rr, "risk_pct": risk / entry if entry else np.nan,
            "potential_pct": t1 / entry - 1 if entry else np.nan,
            "time_stop": TIME_STOP[cat]}


# ---------------------------------------------------------------------------
# Pré-score /100 (technique uniquement)
# ---------------------------------------------------------------------------
REGIME_POINTS = {
    "haussier": {"A": 8, "B": 8, "C": 10, "D": 10},
    "neutre": {"A": 7, "B": 7, "C": 7, "D": 7},
    "baissier": {"A": 4, "B": 4, "C": 2, "D": 2},
}


def prescore(cat, s, m, plan, p1, p3, p6, regime):
    setup = s["setup"]
    if cat in ("A", "B"):
        rs = 20 * (0.3 * p3 + 0.7 * p6)
    else:
        rs = 20 * (0.2 * p1 + 0.4 * p3 + 0.4 * p6)
    vol = 0.0
    v5 = _f(m["vol5_vs_20"], 1)
    obv20, obv60 = _f(m["obv_slope20"], 0), _f(m["obv_slope60"], 0)
    if cat == "A":
        vol = 8 * min(1, _f(m["relvol_max5"], 0) / 3) + (7 if v5 < 1 else 0)
    elif cat == "B":
        vol = (8 if v5 < 0.8 else 4 if v5 < 1 else 0) + (7 if obv20 >= 0 else 0)
    elif cat == "C":
        rv = s.get("breakout_relvol", np.nan)
        vol = (10 * min(1, rv / 3) if np.isfinite(rv) else 3) + (5 if obv20 > 0 else 0)
    else:
        vol = (8 if v5 < 0.9 else 3) + (7 if obv60 > 0 else 0)
    rr = plan["rr"]
    rr_pts = 0 if not np.isfinite(rr) else 15 * min(1, max(0, (rr - 1) / 2))
    reg = REGIME_POINTS.get(regime, REGIME_POINTS["neutre"])[cat]
    total = setup + rs + vol + rr_pts + reg
    return round(total, 1), {"setup": round(setup, 1), "force_relative": round(rs, 1),
                             "volume": round(vol, 1), "rr": round(rr_pts, 1), "regime": reg}


def classify(m: pd.Series, df: pd.DataFrame, rsi: pd.Series, relvol: pd.Series,
             p1: float, p3: float, p6: float, regime: str):
    """Évalue les 4 catégories et garde la meilleure (catégorie principale unique)."""
    sup, res = levels_for(df, m)
    m = m.copy()
    m["_relvol_last3"] = relvol.iloc[-3:].to_numpy(float)
    found = []
    for s in (setup_A(m, df, rsi, relvol), setup_B(m, df, rsi, relvol, sup), setup_C(m, df),
              setup_D(m, df, p3, p6)):
        if s:
            found.append(s)
    if not found:
        return None
    results = []
    for s in found:
        plan = trade_plan(s["cat"], s, m, df, sup, res)
        score, parts = prescore(s["cat"], s, m, plan, p1, p3, p6, regime)
        results.append((score, s, plan, parts))
    results.sort(key=lambda x: -x[0])
    score, s, plan, parts = results[0]
    near_sup = next((x for x in sup if x["level"] <= _f(m["close"])), None)
    near_res = next((x for x in res if x["level"] > _f(m["close"])), None)
    return {
        "category": s["cat"], "category_label": CATEGORY_LABELS[s["cat"]],
        "other_categories": [r[1]["cat"] for r in results[1:]],
        "prescore": score, "score_parts": parts, "signal_notes": s["notes"],
        "status": s.get("status", "setup en place"), "event_date": s.get("event_date"),
        "support": near_sup["level"] if near_sup else np.nan,
        "support_type": near_sup["type"] if near_sup else None,
        "resistance": near_res["level"] if near_res else np.nan,
        "resistance_type": near_res["type"] if near_res else None,
        **plan,
    }
