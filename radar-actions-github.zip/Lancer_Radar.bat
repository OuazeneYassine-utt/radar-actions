@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Radar Actions
set "PYTHONIOENCODING=utf-8"

rem ---- Recherche d'un Python utilisable (3.9+, avec venv) ------------------
rem On ignore les Python embarques (WAPT, raccourci Microsoft Store).
set "PYCMD="
py -3 -c "import sys, venv, ensurepip; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1 && set "PYCMD=py -3"
if exist "%USERPROFILE%\.conda\environments.txt" for /f "usebackq delims=" %%E in ("%USERPROFILE%\.conda\environments.txt") do call :try "%%E\python.exe"
for %%P in ("%USERPROFILE%\anaconda3" "%USERPROFILE%\miniconda3" "%LOCALAPPDATA%\anaconda3" "%LOCALAPPDATA%\miniconda3" "%ProgramData%\anaconda3" "%ProgramData%\miniconda3" "%USERPROFILE%\AppData\Local\Continuum\anaconda3" "C:\anaconda3" "C:\miniconda3") do call :try "%%~P\python.exe"
for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python3*" "%ProgramFiles%\Python3*" "C:\Python3*") do call :try "%%~D\python.exe"
for /f "delims=" %%P in ('where python 2^>nul') do call :try "%%P"

if not defined PYCMD goto nopython
echo Python utilise : %PYCMD%

rem ---- Environnement virtuel et dependances --------------------------------
if exist ".venv" if not exist ".venv\Scripts\python.exe" rmdir /s /q ".venv"
if not exist ".venv\Scripts\python.exe" (
  echo Creation de l'environnement Python local, premiere utilisation...
  %PYCMD% -m venv .venv
)
if not exist ".venv\Scripts\python.exe" goto venvfail
set "VPY=.venv\Scripts\python.exe"
fc /b requirements.txt .venv\req_installed.txt >nul 2>&1
if errorlevel 1 (
  echo Installation des dependances, 1 a 3 minutes la premiere fois...
  "%VPY%" -m pip install --upgrade pip >nul 2>&1
  "%VPY%" -m pip install -r requirements.txt || goto pipfail
  copy /y requirements.txt .venv\req_installed.txt >nul
)

rem ---- Lancement ------------------------------------------------------------
"%VPY%" app.py
echo.
echo L'application s'est arretee.
pause
exit /b 0

rem ---- Teste un python.exe candidat ----------------------------------------
:try
if defined PYCMD exit /b 0
if not exist "%~1" exit /b 1
echo "%~1" | findstr /i "wapt WindowsApps" >nul && exit /b 1
"%~1" -c "import sys, venv, ensurepip; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1 || exit /b 1
set PYCMD="%~1"
exit /b 0

:nopython
echo.
echo Aucun Python utilisable n'a ete trouve.
echo Le Python de WAPT present sur ce PC ne convient pas : il ne sait pas creer d'environnement.
echo.
echo Solution : installez Python 3.12 depuis https://www.python.org/downloads/
echo  - choisissez "Install for current user", pas besoin de droits administrateur ;
echo  - cochez "Add python.exe to PATH" ;
echo puis relancez ce fichier.
echo.
echo Si Anaconda est installe mais pas detecte : ouvrez "Anaconda Prompt", allez dans ce dossier
echo avec la commande cd, puis tapez :  python -m venv .venv
echo et relancez ce fichier.
pause
exit /b 1

:venvfail
echo.
echo Impossible de creer l'environnement Python local dans le dossier .venv
echo Python utilise : %PYCMD%
pause
exit /b 1

:pipfail
echo.
echo L'installation des dependances a echoue. Verifiez votre connexion internet.
echo Sur un reseau d'entreprise, un proxy peut bloquer pip : essayez depuis un autre reseau.
pause
exit /b 1
