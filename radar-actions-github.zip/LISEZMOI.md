# Radar Actions

Application web locale qui fait l'étage quantitatif du radar d'opportunités sur actions (horizon 2 à 12 semaines) :
univers, filtres de liquidité, indicateurs, régime de marché, setups A à D, pré-score, plans de trade, journal de suivi,
et export du fichier + prompt pour l'analyse IA des actualités et des fondamentaux.

## Version site web (GitHub Pages, sans installation)

Le dépôt contient un robot (`.github/workflows/radar.yml`) qui, du lundi au vendredi vers 7 h (heure de Paris),
lance le scan complet, met à jour le journal et publie le site. Mise en place, une seule fois :

1. Déposez ces fichiers dans un dépôt GitHub **public** (par exemple `radar-actions`).
2. Dans le dépôt : **Settings → Pages → Build and deployment → Source : GitHub Actions**.
3. Onglet **Actions** : si GitHub le demande, autorisez les workflows, puis ouvrez « Radar quotidien » → **Run workflow**.
4. Après 15 à 30 minutes, le site est en ligne à l'adresse `https://VOTRE-NOM.github.io/radar-actions/`.

Réglages : modifiez `parametres.json` et `univers/perso.txt` directement sur GitHub (icône crayon).
Le bouton « Relancer le scan » du site ouvre la page GitHub où cliquer sur « Run workflow ».
Le dépôt et le site étant publics, le journal et le capital indiqué dans `parametres.json` sont visibles de tous.

## Version locale — lancer sous Windows

1. Décompressez le dossier où vous voulez (par exemple dans Documents).
2. Double-cliquez sur **Lancer_Radar.bat**.
   - La première fois, il crée un environnement Python dans le dossier et installe les dépendances (1 à 3 minutes, connexion internet nécessaire).
   - Il faut Python 3.10 ou plus récent. S'il manque : https://www.python.org/downloads/ (cochez « Add python.exe to PATH »). Anaconda/Miniconda est aussi détecté.
3. Le navigateur s'ouvre sur http://127.0.0.1:8765. Gardez la fenêtre noire ouverte pendant l'utilisation ; la fermer arrête l'application.

Sur macOS / Linux : `./lancer_radar.sh`.

## Utilisation quotidienne

1. **Lancer le scan** (bouton en haut). En univers complet USA + Europe, comptez 10 à 20 minutes de téléchargement ; un nouveau scan dans les 4 heures réutilise le cache.
2. **Synthèse** : régime de marché, couverture réelle du scan, entonnoir, séances prises en compte, limites.
3. **Opportunités** : titres retenus par catégorie. Cliquez une ligne pour le graphique (entrée, stop, objectifs) et le détail.
4. **Watchlist** : setups présélectionnés non retenus, avec la raison.
5. **Export IA** : téléchargez le CSV, copiez le prompt pré-rempli, collez-le dans votre outil de recherche IA avec le CSV joint.
6. **Journal** : ajoutez les retenus, puis « Mettre à jour les statuts » les jours suivants. Les statistiques par catégorie montrent ce qui marche.

## Ce que fait le moteur

- **Univers** : USA complet (liste officielle NYSE / Nasdaq / NYSE American de nasdaqtrader.com, hors ETF, warrants, préférentielles, SPAC) ; Europe et autres marchés à partir des listes du dossier `univers/` (principales valeurs, pas la cote complète : le rapport de couverture le signale). Ajoutez vos tickers dans l'onglet Paramètres.
- **Filtres** : historique ≥ 210 séances, cotation récente, cours ≥ 3 $ équivalent, volume moyen 20 j en valeur ≥ 5 M$ (USA) / ≈ 2 M€ (autres), capitalisation ≥ 500 M$ (vérifiée sur les présélectionnés).
- **Indicateurs** : performances 1 j à 1 an, MA20/50/100/200, EMA20/50, RSI14, ATR14, MACD, Bollinger (et compression), ADX, OBV, volume relatif, plus hauts/bas 20/50/252 j, pivots, supports et résistances.
- **Régime** : S&P 500 et STOXX 600 vs MA50/MA200, % de titres au-dessus de leur MA50, VIX. En régime baissier : R/R minimum 3, 5 titres maximum, breakouts et momentum seulement avec force relative exceptionnelle.
- **Setups** (une catégorie principale par titre) :
  - A sur-réaction : baisse ≥ 2 ATR en une séance, ≥ 15 % sur 1 mois ou gap ≥ 5 %.
  - B support : repli d'au moins 5 % vers un support majeur à 0–5 %, avec signes de stabilisation.
  - C breakout : base ≤ 25 % sur 40 j et ≤ 15 % sur 20 j, cassure du plus haut 50 j (volume relatif ≥ 1,5) ou à moins de 3 %.
  - D momentum : MA50 > MA200, ADX ≥ 20, force relative 3 et 6 mois dans le premier tiers, repli sur EMA20/MA50.
- **Pré-score /100 (technique)** : setup 40, force relative 20, volume 15, R/R 15, régime 10.
- **Plan** : entrée de confirmation, stop technique borné entre 1 et 3 ATR (sinon 1,5 ou 2,5 ATR), objectif = prochaine résistance ≥ 1 ATR, stop temporel 3 ou 6 semaines, taille de position selon votre capital et risque par position.

## Limites à connaître

- Les données viennent de Yahoo Finance via `yfinance` (gratuit, non officiel). Si les téléchargements échouent, lancez **Mettre_a_jour_donnees_Yahoo.bat**.
- Les ratios fondamentaux et dates de résultats Yahoo sont indicatifs : l'étape IA doit les vérifier.
- Le pré-score est purement technique. Les catalyseurs, la cause des baisses et la qualité fondamentale relèvent de l'étape IA.
- Recherche analytique, pas un conseil financier personnalisé.

## Fichiers

- `data/scans/` : chaque scan (JSON), consultable via « Historique ».
- `data/exports/` : CSV exportés.
- `data/journal.csv` : le journal (séparateur « ; », s'ouvre dans Excel).
- `univers/` : listes de tickers modifiables.
