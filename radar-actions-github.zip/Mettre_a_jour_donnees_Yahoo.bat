@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Lancez d'abord Lancer_Radar.bat une premiere fois.
  pause
  exit /b 1
)
echo Mise a jour de yfinance, a faire si les telechargements de cours echouent...
".venv\Scripts\python.exe" -m pip install --upgrade yfinance
pause
