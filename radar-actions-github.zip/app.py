"""Radar Actions — application web locale.

Lancement : double-clic sur « Lancer_Radar.bat » (Windows) ou `python app.py`.
L'interface s'ouvre dans le navigateur à l'adresse http://127.0.0.1:8765
"""
from __future__ import annotations

import json
import os
import sys
import threading
import webbrowser
from datetime import datetime, timedelta

import numpy as np
import pandas as pd
from flask import Flask, jsonify, request, send_from_directory, Response

from radar import data as D
from radar import journal as J
from radar.config import (DEFAULT_SETTINGS, SETTINGS_FILE, SCANS_DIR, UNIVERSE_DIR, HOST, PORT,
                          CATEGORY_LABELS)
from radar.exporter import scan_csv, prompt_text
from radar.pipeline import ScanJob, clean
from radar.universe import read_list_file

BASE = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__, static_folder=os.path.join(BASE, "static"), static_url_path="/static")
JOB = ScanJob()


# ---------------------------------------------------------------------------
def load_settings() -> dict:
    st = dict(DEFAULT_SETTINGS)
    root = os.path.join(BASE, "parametres.json")
    if os.path.exists(root):
        try:
            st.update(json.loads(open(root, encoding="utf-8").read()))
        except Exception:
            pass
    if SETTINGS_FILE.exists():
        try:
            st.update(json.loads(SETTINGS_FILE.read_text(encoding="utf-8")))
        except Exception:
            pass
    return st


def current_result():
    if JOB.result is not None:
        return JOB.result
    f = SCANS_DIR / "dernier_scan.json"
    if f.exists():
        try:
            JOB.result = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            return None
    return JOB.result


def get_prices(tickers: list[str]) -> dict:
    out = {}
    pool = JOB.prices or {}
    if not pool:
        pool, _ = D.load_price_cache(max_age_h=24 * 365)
        JOB.prices = pool
    missing = [t for t in tickers if t not in pool]
    for t in tickers:
        if t in pool:
            out[t] = pool[t]
    if missing:
        start = (datetime.now() - timedelta(days=420)).strftime("%Y-%m-%d")
        got = D.get_provider().download(missing, start, chunk_size=100, pause_s=0.3)
        out.update(got)
        pool.update(got)
    return out


# ---------------------------------------------------------------------------
@app.route("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


@app.get("/api/settings")
def api_settings():
    return jsonify(load_settings())


@app.post("/api/settings")
def api_settings_save():
    st = load_settings()
    body = request.get_json(force=True) or {}
    for k, v in body.items():
        if k in DEFAULT_SETTINGS:
            st[k] = v
    SETTINGS_FILE.write_text(json.dumps(st, ensure_ascii=False, indent=2), encoding="utf-8")
    return jsonify(st)


@app.post("/api/scan")
def api_scan():
    body = request.get_json(silent=True) or {}
    ok = JOB.start(load_settings(), use_cache=body.get("use_cache", True))
    return jsonify({"started": ok, "message": None if ok else "Un scan est déjà en cours."})


@app.get("/api/status")
def api_status():
    s = JOB.status()
    s["demo"] = D.DEMO
    return jsonify(s)


@app.get("/api/result")
def api_result():
    res = current_result()
    return jsonify(res or {})


@app.get("/api/scans")
def api_scans():
    files = sorted(SCANS_DIR.glob("scan_*.json"), reverse=True)[:60]
    return jsonify([f.stem for f in files])


@app.get("/api/scans/<name>")
def api_scan_load(name):
    f = SCANS_DIR / f"{name}.json"
    if not f.exists() or not name.startswith("scan_"):
        return jsonify({"error": "introuvable"}), 404
    JOB.result = json.loads(f.read_text(encoding="utf-8"))
    return jsonify(JOB.result)


@app.get("/api/chart/<ticker>")
def api_chart(ticker):
    px = get_prices([ticker]).get(ticker)
    if px is None or px.empty:
        return jsonify({"error": "Cours indisponibles pour ce titre."}), 404
    df = px.dropna(subset=["Close"]).copy()
    c = df["Close"]
    df["ma20"] = c.rolling(20).mean()
    df["ma50"] = c.rolling(50).mean()
    df["ma200"] = c.rolling(200).mean()
    df = df.iloc[-260:]
    res = current_result() or {}
    plan = next((r for r in (res.get("retained", []) + res.get("watchlist", [])) if r["ticker"] == ticker), None)
    return jsonify(clean({
        "ticker": ticker,
        "dates": [d.strftime("%Y-%m-%d") for d in df.index],
        "open": df["Open"].tolist(), "high": df["High"].tolist(), "low": df["Low"].tolist(),
        "close": df["Close"].tolist(), "volume": df["Volume"].tolist(),
        "ma20": df["ma20"].tolist(), "ma50": df["ma50"].tolist(), "ma200": df["ma200"].tolist(),
        "plan": {k: plan.get(k) for k in ("entry", "stop", "target1", "target2", "support", "resistance")} if plan else None,
    }))


@app.get("/api/export/csv")
def api_export_csv():
    res = current_result()
    if not res:
        return jsonify({"error": "Aucun scan disponible."}), 404
    name, txt = scan_csv(res)
    return Response("﻿" + txt, mimetype="text/csv",
                    headers={"Content-Disposition": f"attachment; filename={name}"})


@app.get("/api/export/prompt")
def api_export_prompt():
    res = current_result()
    if not res:
        return jsonify({"error": "Aucun scan disponible."}), 404
    return jsonify({"prompt": prompt_text(res)})


@app.get("/api/journal")
def api_journal():
    df = J.load()
    return jsonify({"rows": df.to_dict(orient="records"), "stats": clean(J.stats(df))})


@app.post("/api/journal/add")
def api_journal_add():
    res = current_result()
    if not res:
        return jsonify({"error": "Aucun scan disponible."}), 404
    body = request.get_json(force=True) or {}
    wanted = set(body.get("tickers") or [])
    pool = res.get("retained", []) + res.get("watchlist", [])
    rows = [r for r in pool if r["ticker"] in wanted] if wanted else res.get("retained", [])
    n = J.add(rows, res["meta"]["finished"][:10])
    return jsonify({"added": n})


@app.post("/api/journal/update")
def api_journal_update():
    try:
        df, missing = J.update(get_prices)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500
    return jsonify({"rows": df.to_dict(orient="records"), "stats": clean(J.stats(df)), "missing": missing})


@app.delete("/api/journal/<entry_id>")
def api_journal_delete(entry_id):
    J.delete(entry_id)
    return jsonify({"ok": True})


@app.get("/api/journal/csv")
def api_journal_csv():
    df = J.load()
    return Response("﻿" + df.to_csv(sep=";", index=False), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=journal_signaux.csv"})


@app.get("/api/universe")
def api_universe():
    perso = UNIVERSE_DIR / "perso.txt"
    return jsonify({
        "europe": len(read_list_file("europe.txt")), "autres": len(read_list_file("autres.txt")),
        "usa_rapide": len(read_list_file("usa_rapide.txt")),
        "perso_text": perso.read_text(encoding="utf-8") if perso.exists() else "",
        "folder": str(UNIVERSE_DIR),
    })


@app.post("/api/universe/perso")
def api_universe_perso():
    body = request.get_json(force=True) or {}
    (UNIVERSE_DIR / "perso.txt").write_text(body.get("text", ""), encoding="utf-8")
    return jsonify({"count": len(read_list_file("perso.txt"))})


def main():
    url = f"http://{HOST}:{PORT}"
    print("=" * 60)
    print(" Radar Actions — application locale")
    print(f" Ouvrez {url} dans votre navigateur (ouverture automatique).")
    print(" Pour arrêter : fermez cette fenêtre ou Ctrl+C.")
    if D.DEMO:
        print(" MODE DÉMO : données simulées.")
    print("=" * 60)
    if "--no-browser" not in sys.argv:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    app.run(host=HOST, port=PORT, debug=False, threaded=True)


if __name__ == "__main__":
    main()
