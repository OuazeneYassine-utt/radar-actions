"""Construit le site statique du radar (GitHub Pages).

Exécuté chaque matin par GitHub Actions (.github/workflows/radar.yml) :
scan complet → mise à jour du journal → génération du dossier site/.
Test local sans réseau : RADAR_DEMO=1 python build_site.py
"""
from __future__ import annotations

import json
import os
import re
import shutil
from datetime import datetime, timedelta
from pathlib import Path

from radar import data as D
from radar import journal as J
from radar.config import DEFAULT_SETTINGS, SCANS_DIR, UNIVERSE_DIR, JOURNAL_FILE
from radar.exporter import scan_csv, prompt_text
from radar.pipeline import run_scan, clean
from radar.universe import read_list_file

BASE = Path(__file__).resolve().parent
SITE = BASE / "site"
KEEP_SCANS = 30
SCHEDULE = "Mise à jour automatique du lundi au vendredi vers 7 h (heure de Paris)"


def safe_name(t: str) -> str:
    return re.sub(r"[^A-Za-z0-9]", "_", t)


def load_settings() -> dict:
    st = dict(DEFAULT_SETTINGS)
    f = BASE / "parametres.json"
    if f.exists():
        user = json.loads(f.read_text(encoding="utf-8"))
        st.update({k: v for k, v in user.items() if k in DEFAULT_SETTINGS})
    return st


def write_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(clean(obj), ensure_ascii=False), encoding="utf-8")


def chart_payload(ticker, px, plan):
    df = px.dropna(subset=["Close"]).copy()
    c = df["Close"]
    df["ma20"], df["ma50"], df["ma200"] = c.rolling(20).mean(), c.rolling(50).mean(), c.rolling(200).mean()
    df = df.iloc[-260:]
    return {"ticker": ticker, "dates": [d.strftime("%Y-%m-%d") for d in df.index],
            "open": df["Open"].round(4).tolist(), "high": df["High"].round(4).tolist(),
            "low": df["Low"].round(4).tolist(), "close": df["Close"].round(4).tolist(),
            "volume": df["Volume"].tolist(), "ma20": df["ma20"].round(4).tolist(),
            "ma50": df["ma50"].round(4).tolist(), "ma200": df["ma200"].round(4).tolist(),
            "plan": {k: plan.get(k) for k in ("entry", "stop", "target1", "target2", "support", "resistance")} if plan else None}


def main():
    settings = load_settings()
    print("Paramètres :", {k: settings[k] for k in ("regions", "us_mode", "min_rr", "capital_eur", "risk_pct")})
    res, prices = run_scan(settings, use_cache=False)
    scan_date = res["meta"]["finished"][:10]

    # Journal : mise à jour des statuts puis ajout des titres retenus du jour
    provider = D.get_provider()

    def lookup(tickers):
        out = {t: prices[t] for t in tickers if t in prices}
        missing = [t for t in tickers if t not in out]
        if missing:
            start = (datetime.now() - timedelta(days=420)).strftime("%Y-%m-%d")
            got = provider.download(missing, start, chunk_size=100, pause_s=0.5)
            D.trim_incomplete_sessions(got)
            out.update(got)
        return out

    jdf, missing = J.update(lookup)
    if missing:
        print("Journal : cours indisponibles pour", ", ".join(missing))
    added = J.add(res["retained"], scan_date)
    print(f"Journal : {added} titre(s) ajouté(s)")
    jdf = J.load()

    # Historique des scans (on garde les 30 derniers)
    scans = sorted(SCANS_DIR.glob("scan_*.json"))
    for old in scans[:-KEEP_SCANS]:
        old.unlink()
    scans = sorted(SCANS_DIR.glob("scan_*.json"), reverse=True)

    # Site
    if SITE.exists():
        shutil.rmtree(SITE)
    (SITE / "static").mkdir(parents=True)
    for f in ("app.js", "style.css"):
        shutil.copy(BASE / "static" / f, SITE / "static" / f)
    html = (BASE / "static" / "index.html").read_text(encoding="utf-8")
    html = html.replace("<body>", '<body data-mode="static">', 1).replace('"/static/', '"static/')
    (SITE / "index.html").write_text(html, encoding="utf-8")
    (SITE / ".nojekyll").write_text("")

    d = SITE / "data"
    write_json(d / "dernier_scan.json", res)
    (d / "scans").mkdir(parents=True, exist_ok=True)
    for f in scans:
        shutil.copy(f, d / "scans" / f.name)
    write_json(d / "scans" / "index.json", [f.stem for f in scans])
    _, csv_txt = scan_csv(res)
    (d / "radar.csv").write_text("﻿" + csv_txt, encoding="utf-8")
    write_json(d / "prompt.json", {"prompt": prompt_text(res)})
    write_json(d / "journal.json", {"rows": jdf.to_dict(orient="records"), "stats": J.stats(jdf)})
    shutil.copy(JOURNAL_FILE, d / "journal.csv") if JOURNAL_FILE.exists() else None
    write_json(d / "status.json", {"running": False, "progress": 100, "stage": "Terminé", "logs": [],
                                   "error": None, "has_result": True, "demo": D.DEMO})
    write_json(d / "settings.json", settings)
    write_json(d / "universe.json", {
        "europe": len(read_list_file("europe.txt")), "autres": len(read_list_file("autres.txt")),
        "usa_rapide": len(read_list_file("usa_rapide.txt")),
        "perso_text": (UNIVERSE_DIR / "perso.txt").read_text(encoding="utf-8") if (UNIVERSE_DIR / "perso.txt").exists() else "",
        "folder": "univers/ (dans le dépôt GitHub)"})
    repo = os.environ.get("GITHUB_REPOSITORY", "")
    gh = f"https://github.com/{repo}" if repo else "https://github.com"
    write_json(d / "site.json", {
        "repo": repo, "schedule": SCHEDULE,
        "actions_url": f"{gh}/actions/workflows/radar.yml",
        "edit_params_url": f"{gh}/edit/main/parametres.json",
        "edit_perso_url": f"{gh}/edit/main/univers/perso.txt",
    })

    # Graphiques : retenus, watchlist et meilleurs signaux
    plans = {r["ticker"]: r for r in res["retained"] + res["watchlist"]}
    tickers = list(plans) + [s["ticker"] for s in res["all_signals"][:200]]
    n = 0
    for t in dict.fromkeys(tickers):
        px = prices.get(t)
        if px is None or px.empty:
            continue
        write_json(d / "charts" / f"{safe_name(t)}.json", chart_payload(t, px, plans.get(t)))
        n += 1
    print(f"Site généré : {SITE} ({n} graphiques). {res['pipeline']}")


if __name__ == "__main__":
    main()
