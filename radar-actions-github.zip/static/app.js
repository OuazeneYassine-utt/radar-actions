/* Radar Actions — interface */
"use strict";

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const isNum = (x) => typeof x === "number" && isFinite(x);
const nf = (d) => new Intl.NumberFormat("fr-FR", { minimumFractionDigits: d, maximumFractionDigits: d });
const num = (x, d = 2) => (isNum(x) ? nf(d).format(x) : "n.d.");
const pct = (x, d = 1, sign = true) => (isNum(x) ? (sign && x > 0 ? "+" : "") + nf(d).format(x * 100) + " %" : "n.d.");
const pctCls = (x) => (isNum(x) ? (x > 0 ? "pos" : x < 0 ? "neg" : "") : "");
const big = (x) => {
  if (!isNum(x)) return "n.d.";
  const a = Math.abs(x);
  if (a >= 1e12) return nf(2).format(x / 1e12) + " T$";
  if (a >= 1e9) return nf(1).format(x / 1e9) + " Md$";
  if (a >= 1e6) return nf(0).format(x / 1e6) + " M$";
  return nf(0).format(x) + " $";
};
const price = (x, cur) => (isNum(x) ? nf(x >= 1000 ? 0 : x >= 100 ? 1 : 2).format(x) + (cur ? " " + (cur === "GBp" ? "p" : cur) : "") : "n.d.");
const dateFr = (s) => (s ? s.slice(8, 10) + "/" + s.slice(5, 7) + "/" + s.slice(0, 4) : "n.d.");

/* Mode « site statique » (GitHub Pages) : les données sont des fichiers JSON générés chaque matin */
const STATIC = document.body.dataset.mode === "static";
const safeName = (t) => t.replace(/[^A-Za-z0-9]/g, "_");
function staticUrl(url) {
  const m = url.match(/^\/api\/(chart|scans)\/(.+)$/);
  if (m && m[1] === "chart") return "data/charts/" + safeName(decodeURIComponent(m[2])) + ".json";
  if (m && m[1] === "scans") return "data/scans/" + m[2] + ".json";
  return ({ "/api/result": "data/dernier_scan.json", "/api/scans": "data/scans/index.json",
    "/api/journal": "data/journal.json", "/api/export/prompt": "data/prompt.json",
    "/api/status": "data/status.json", "/api/settings": "data/settings.json",
    "/api/universe": "data/universe.json" })[url] || null;
}
async function api(url, opts = {}) {
  if (STATIC) {
    const su = staticUrl(url);
    if (!su || (opts.method && opts.method !== "GET")) throw new Error("Indisponible sur le site (lecture seule).");
    const r = await fetch(su + "?v=" + Date.now());
    if (!r.ok) throw new Error(r.status === 404 ? "Données non disponibles pour ce titre." : r.statusText);
    return r.json();
  }
  const r = await fetch(url, { headers: { "Content-Type": "application/json" }, ...opts });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || r.statusText);
  return j;
}

let RESULT = null;
let POLL = null;

/* ---------------- Onglets ---------------- */
$$(".tabs button").forEach((b) =>
  b.addEventListener("click", () => {
    $$(".tabs button").forEach((x) => x.classList.toggle("active", x === b));
    $$(".tab").forEach((t) => t.classList.toggle("active", t.id === "tab-" + b.dataset.tab));
    if (b.dataset.tab === "journal") loadJournal();
    if (b.dataset.tab === "export") loadPrompt();
    if (b.dataset.tab === "params") loadParams();
  })
);

/* ---------------- Scan ---------------- */
$("#btnScan").addEventListener("click", async () => {
  try {
    const r = await api("/api/scan", { method: "POST", body: JSON.stringify({ use_cache: $("#useCache").checked }) });
    if (!r.started) alert(r.message);
    startPolling();
  } catch (e) { alert("Impossible de lancer le scan : " + e.message); }
});

function startPolling() {
  $("#progress").classList.remove("hidden");
  $("#btnScan").disabled = true;
  clearInterval(POLL);
  POLL = setInterval(pollStatus, 1200);
  pollStatus();
}

async function pollStatus() {
  let s;
  try { s = await api("/api/status"); } catch { return; }
  $("#demoBanner").classList.toggle("hidden", !s.demo);
  $("#stage").textContent = s.stage;
  $("#pct").textContent = Math.round(s.progress) + " %";
  $("#barFill").style.width = s.progress + "%";
  $("#logs").textContent = s.logs.join("\n");
  $("#logs").scrollTop = 1e9;
  if (!s.running) {
    clearInterval(POLL);
    $("#btnScan").disabled = false;
    if (s.error) { $("#stage").textContent = "Erreur : " + s.error; $("#progress details").open = true; }
    else { setTimeout(() => $("#progress").classList.add("hidden"), 2500); await loadResult(); await loadHistory(); }
  }
}

async function loadHistory() {
  try {
    const list = await api("/api/scans");
    const sel = $("#history");
    sel.innerHTML = '<option value="">Historique…</option>' + list.map((n) => {
      const m = n.match(/scan_(\d{4})(\d{2})(\d{2})_(\d{2})(\d{2})/);
      return `<option value="${n}">${m ? `${m[3]}/${m[2]}/${m[1]} ${m[4]}:${m[5]}` : n}</option>`;
    }).join("");
  } catch {}
}
$("#history").addEventListener("change", async (e) => {
  if (!e.target.value) return;
  RESULT = await api("/api/scans/" + e.target.value);
  render();
});

async function loadResult() {
  RESULT = await api("/api/result");
  render();
}

/* ---------------- Rendu ---------------- */
function render() {
  const has = RESULT && RESULT.meta;
  $("#empty").classList.toggle("hidden", !!has);
  $("#synth").classList.toggle("hidden", !has);
  if (!has) return;
  const m = RESULT.meta, reg = RESULT.regime, cov = RESULT.coverage;
  $("#demoBanner").classList.toggle("hidden", !m.demo);
  $("#scanLabel").textContent = "Scan du " + m.started_label + " · " + m.provider;
  const pill = $("#regimePill");
  pill.className = "pill " + reg.regime;
  pill.textContent = "Régime " + reg.regime;
  $("#cRet").textContent = RESULT.retained.length;
  $("#cWatch").textContent = RESULT.watchlist.length;
  $("#cSig").textContent = cov.signals;

  // bannière de couverture partielle
  const pb = $("#partialBanner");
  if (cov.partial) {
    pb.classList.remove("hidden");
    pb.innerHTML = "<strong>Le scan n'a couvert qu'une partie de l'univers disponible.</strong> " +
      esc(Object.entries(cov.universe_sources).filter(([, s]) => /liste intégrée/.test(s)).map(([r, s]) => r + " : " + s).join(" · ")) +
      (cov.no_data ? ` · ${cov.no_data} titres sans données téléchargeables.` : "");
  } else pb.classList.add("hidden");

  // Régime
  const idxRows = Object.entries(reg.indices).map(([n, x]) => x ? `<tr><td>${esc(n)}</td><td class="num">${num(x.close, 0)}</td>
      <td class="${x.above_ma50 ? "pos" : "neg"}">${x.above_ma50 ? "au-dessus" : "en dessous"}</td>
      <td class="${x.above_ma200 ? "pos" : "neg"}">${x.above_ma200 ? "au-dessus" : "en dessous"}</td>
      <td class="num ${pctCls(x.ret_1m)}">${pct(x.ret_1m)}</td><td class="num ${pctCls(x.ret_3m)}">${pct(x.ret_3m)}</td></tr>`
    : `<tr><td>${esc(n)}</td><td colspan="5" class="muted">n.d.</td></tr>`).join("");
  const br = Object.entries(reg.breadth || {}).map(([r, b]) => `<div><span>${esc(r)} · titres &gt; MA50</span><b>${pct(b.above_ma50, 0, false)}</b></div>`).join("");
  $("#regimeBox").innerHTML = `
    <div class="regime-head"><span class="regime-name ${reg.regime}">${esc(reg.regime)}</span></div>
    <ul class="plain">${reg.reasons.map((r) => `<li>${esc(r)}</li>`).join("")}</ul>
    <p><strong>Implication :</strong> ${esc(reg.implications)}</p>
    <div class="table-wrap"><table><thead><tr><th>Indice</th><th class="num">Clôture</th><th>MA50</th><th>MA200</th><th class="num">1 m</th><th class="num">3 m</th></tr></thead><tbody>${idxRows}</tbody></table></div>
    <div class="kv"><div><span>VIX</span><b>${num(reg.vix, 1)}</b></div><div><span>Taux 10 ans US</span><b>${isNum(reg.us10y) ? num(reg.us10y, 2) + " %" : "n.d."}</b></div>${br}</div>`;

  // Couverture
  const ex = Object.entries(cov.exclusions).map(([k, v]) => `<tr><td>${esc(k)}</td><td class="num">${v}</td></tr>`).join("");
  const regs = Object.keys(cov.universe_by_region);
  $("#coverageBox").innerHTML = `
    <div class="kv" style="margin-bottom:12px">
      <div><span>Univers identifié</span><b>${cov.universe_identified}</b></div>
      <div><span>Réellement scanné</span><b>${cov.downloaded}</b></div>
      <div><span>Couverture estimée</span><b>${num(cov.coverage_pct, 0)} %</b></div>
    </div>
    <div class="table-wrap"><table><thead><tr><th>Région</th><th class="num">Identifiés</th><th class="num">Téléchargés</th><th class="num">Après filtres</th></tr></thead><tbody>
    ${regs.map((r) => `<tr><td>${esc(r)}</td><td class="num">${cov.universe_by_region[r] || 0}</td><td class="num">${cov.downloaded_by_region[r] || 0}</td><td class="num">${cov.scanned_by_region[r] || 0}</td></tr>`).join("")}
    </tbody></table></div>
    <div class="table-wrap"><table><thead><tr><th>Exclusion</th><th class="num">Titres</th></tr></thead><tbody>
    <tr><td>sans données téléchargeables</td><td class="num">${cov.no_data}</td></tr>${ex}
    <tr><td>capitalisation &lt; seuil (après enrichissement)</td><td class="num">${cov.excluded_mcap}</td></tr></tbody></table></div>`;

  // Entonnoir
  const steps = [
    ["Univers identifié", cov.universe_identified], ["Téléchargés", cov.downloaded], ["Analysés (après filtres)", cov.scanned],
    ["Signaux (≥ 1 setup)", cov.signals], ["Présélectionnés et enrichis", cov.preselected],
    ["Approfondis (étape IA)", cov.deep_ai], ["Retenus", cov.retained], ["Watchlist", cov.watchlist],
  ];
  const mx = Math.max(1, cov.universe_identified);
  const byCat = Object.entries(cov.signals_by_category).sort().map(([c, n]) => `<span class="cat ${c}">${c}</span> ${n}`).join(" &nbsp; ");
  $("#funnel").innerHTML = `<p style="margin-top:0"><strong>${esc(RESULT.pipeline)}</strong></p><div class="funnel">` +
    steps.map(([l, n]) => `<div class="step"><div class="lab">${l}</div><div class="fb"><div style="width:${Math.max(0.4, (100 * n) / mx)}%"></div></div><div class="n">${n}</div></div>`).join("") +
    `</div><p class="muted" style="margin-bottom:0">Signaux par catégorie : ${byCat || "aucun"}</p>`;

  // Séances et sources
  $("#sessionsBox").innerHTML = `<div class="kv">${Object.entries(m.last_sessions).sort().map(([k, v]) => `<div><span>${esc(k)}</span><b>${dateFr(v)}</b></div>`).join("")}</div>
     <p class="muted" style="margin-bottom:0">${esc(m.fundamentals_note)}</p>`;
  const src = Object.entries(cov.universe_sources).map(([k, v]) => `<li><strong>${esc(k)}</strong> : ${esc(v)}</li>`).join("");
  $("#sourcesBox").innerHTML = `<ul class="plain">${src}
      <li>Cours : ${esc(m.provider)}${m.prices_fetched_at ? ", téléchargés le " + dateFr(m.prices_fetched_at.slice(0, 10)) + " à " + m.prices_fetched_at.slice(11, 16) : ""}</li>
      ${m.fx_estimated && m.fx_estimated.length ? `<li class="flag">Taux de change estimés (non téléchargés) : ${esc(m.fx_estimated.join(", "))}</li>` : ""}
      ${cov.no_data_sample.length ? `<li>Exemples sans données : ${esc(cov.no_data_sample.slice(0, 15).join(", "))}</li>` : ""}
      <li>« Approfondis » reste à 0 : l'analyse des actualités et des fondamentaux se fait avec l'Export IA.</li></ul>`;

  renderOpps();
  renderWatch();
  renderSignals();
}

function scoreCell(s) {
  return `<span class="score"><i><b style="width:${Math.min(100, s)}%"></b></i>${num(s, 0)}</span>`;
}

function oppTable(rows, withReasons) {
  const cols = [
    ["Titre", (r) => `<span class="tk">${esc(r.ticker)}</span><div class="muted">${esc((r.name || "").slice(0, 28))} · ${esc(r.market)}</div>`, "ticker"],
    ["Cat.", (r) => `<span class="cat ${r.category}" title="${esc(r.category_label)}">${r.category}</span>`, "category"],
    ["Pré-score", (r) => scoreCell(r.prescore), "prescore", "num"],
    ["Cours", (r) => price(r.close, r.currency) + `<div class="muted">${dateFr(r.date)}</div>`, "close", "num"],
    ["Setup", (r) => esc(r.status) + (r.flags && r.flags.length ? ` <span class="flag" title="${esc(r.flags.join(" · "))}">⚠</span>` : ""), "status"],
    ["Support", (r) => price(r.support), "support", "num"],
    ["Résistance", (r) => price(r.resistance), "resistance", "num"],
    ["Entrée", (r) => price(r.entry), "entry", "num"],
    ["Stop", (r) => price(r.stop) + `<div class="muted">${isNum(r.risk_pct) ? pct(-r.risk_pct, 1) : ""}</div>`, "stop", "num"],
    ["Objectif 1", (r) => price(r.target1) + `<div class="muted pos">${pct(r.potential_pct, 1)}</div>`, "target1", "num"],
    ["R/R", (r) => num(r.rr, 1), "rr", "num"],
    ["Résultats", (r) => (r.earnings_date ? dateFr(r.earnings_date) + (isNum(r.days_to_earnings) ? `<div class="muted">J+${r.days_to_earnings}</div>` : "") : "n.d."), "days_to_earnings"],
    ["Taille", (r) => (r.position_shares ? `${r.position_shares} titres<div class="muted">${num(r.position_eur, 0)} €</div>` : "n.d."), "position_eur", "num"],
  ];
  if (withReasons) cols.push(["Pourquoi pas retenu", (r) => esc((r.not_retained_reasons || []).join(" · ")), null, "wrap"]);
  return sortableTable(cols, rows, (r) => openDetail(r));
}

function sortableTable(cols, rows, onClick) {
  const wrap = document.createElement("div");
  wrap.className = "table-wrap";
  let sortKey = null, dir = -1;
  const draw = () => {
    let data = rows.slice();
    if (sortKey) data.sort((a, b) => {
      const x = a[sortKey], y = b[sortKey];
      if (x == null) return 1; if (y == null) return -1;
      return (x > y ? 1 : x < y ? -1 : 0) * dir;
    });
    wrap.innerHTML = `<table><thead><tr>${cols.map((c, i) => `<th data-i="${i}" class="${c[3] || ""}">${c[0]}</th>`).join("")}</tr></thead>
      <tbody>${data.map((r, k) => `<tr data-k="${k}">${cols.map((c) => `<td class="${c[3] || ""}">${c[1](r)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
    $$("th", wrap).forEach((th) => th.addEventListener("click", () => {
      const c = cols[+th.dataset.i]; if (!c[2]) return;
      if (sortKey === c[2]) dir = -dir; else { sortKey = c[2]; dir = -1; }
      draw();
    }));
    if (onClick) $$("tbody tr", wrap).forEach((tr) => tr.addEventListener("click", () => onClick(data[+tr.dataset.k])));
  };
  draw();
  return wrap;
}

function renderOpps() {
  const box = $("#oppsBox");
  box.innerHTML = "";
  const rows = RESULT.retained;
  if (!rows.length) {
    box.innerHTML = `<div class="card"><strong>Aucune opportunité retenue aujourd'hui.</strong><p class="muted">Aucun titre ne remplit tous les critères (régime ${esc(RESULT.regime.regime)}, R/R minimum ${num(RESULT.meta.min_rr, 1)}). Consultez la watchlist.</p></div>`;
    return;
  }
  if (RESULT.correlations && RESULT.correlations.length) {
    const d = document.createElement("div");
    d.className = "banner info";
    d.innerHTML = "<strong>Titres fortement corrélés (60 séances) :</strong> " + RESULT.correlations.map((c) => `${esc(c.a)} / ${esc(c.b)} (${num(c.corr, 2)})`).join(", ");
    box.appendChild(d);
  }
  for (const cat of ["A", "B", "C", "D"]) {
    const sub = rows.filter((r) => r.category === cat);
    if (!sub.length) continue;
    const h = document.createElement("div");
    h.className = "cat-title";
    h.innerHTML = `<span class="cat ${cat}">${cat}</span><h3>${esc(RESULT.category_labels[cat])}</h3><span class="muted">${sub.length} titre${sub.length > 1 ? "s" : ""}</span>`;
    box.appendChild(h);
    box.appendChild(oppTable(sub, false));
  }
}

function renderWatch() {
  const box = $("#watchBox");
  box.innerHTML = "";
  if (!RESULT.watchlist.length) { box.innerHTML = '<p class="muted">Watchlist vide.</p>'; return; }
  box.appendChild(oppTable(RESULT.watchlist, true));
}

function renderSignals() {
  const markets = [...new Set(RESULT.all_signals.map((s) => s.market))].sort();
  const sel = $("#sigMarket");
  const cur = sel.value;
  sel.innerHTML = '<option value="">Toutes places</option>' + markets.map((m) => `<option ${m === cur ? "selected" : ""}>${esc(m)}</option>`).join("");
  drawSignals();
}
function drawSignals() {
  if (!RESULT || !RESULT.all_signals) return;
  const q = $("#sigSearch").value.trim().toUpperCase(), c = $("#sigCat").value, mk = $("#sigMarket").value;
  const rows = RESULT.all_signals.filter((s) => (!q || s.ticker.includes(q)) && (!c || s.category === c) && (!mk || s.market === mk));
  const cols = [
    ["Titre", (r) => `<span class="tk">${esc(r.ticker)}</span> <span class="muted">${esc(r.market)}</span>`, "ticker"],
    ["Cat.", (r) => `<span class="cat ${r.category}">${r.category}</span>`, "category"],
    ["Pré-score", (r) => scoreCell(r.prescore), "prescore", "num"],
    ["Cours", (r) => price(r.close, r.currency), "close", "num"],
    ["1 j", (r) => `<span class="${pctCls(r.ret_1d)}">${pct(r.ret_1d)}</span>`, "ret_1d", "num"],
    ["1 m", (r) => `<span class="${pctCls(r.ret_1m)}">${pct(r.ret_1m)}</span>`, "ret_1m", "num"],
    ["RSI", (r) => num(r.rsi, 0), "rsi", "num"],
    ["Vol. rel.", (r) => num(r.relvol, 1), "relvol", "num"],
    ["R/R", (r) => num(r.rr, 1), "rr", "num"],
    ["Signaux", (r) => esc(r.notes.join(" · ")), null, "wrap"],
  ];
  const box = $("#sigBox");
  box.innerHTML = `<p class="muted">${rows.length} signaux affichés${RESULT.all_signals.length >= 600 ? " (600 meilleurs pré-scores conservés)" : ""}. Cliquez pour le graphique.</p>`;
  box.appendChild(sortableTable(cols, rows.slice(0, 600), (r) => {
    const full = RESULT.retained.concat(RESULT.watchlist).find((x) => x.ticker === r.ticker);
    openDetail(full || { ...r, light: true, signal_notes: r.notes, category_label: RESULT.category_labels[r.category] });
  }));
}
["input", "change"].forEach((ev) => { $("#sigSearch").addEventListener(ev, drawSignals); $("#sigCat").addEventListener(ev, drawSignals); $("#sigMarket").addEventListener(ev, drawSignals); });

/* ---------------- Détail ---------------- */
function closeDetail() { $("#drawer").classList.add("hidden"); $("#scrim").classList.add("hidden"); }
$("#dClose").addEventListener("click", closeDetail);
$("#scrim").addEventListener("click", closeDetail);
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeDetail(); });

async function openDetail(r) {
  $("#drawer").classList.remove("hidden");
  $("#scrim").classList.remove("hidden");
  $("#dTitle").innerHTML = `<span class="cat ${r.category}">${r.category}</span> ${esc(r.ticker)} ${r.name ? `<span class="muted" style="font-weight:400;font-size:15px">${esc(r.name)}</span>` : ""}`;
  $("#dSub").textContent = [r.market, r.sector, r.industry, r.category_label].filter(Boolean).join(" · ");
  const yahoo = `https://finance.yahoo.com/quote/${encodeURIComponent(r.ticker)}`;
  let html = "";
  if (!r.light) {
    const parts = r.score_parts || {};
    const maxes = { setup: 40, force_relative: 20, volume: 15, rr: 15, regime: 10 };
    const labels = { setup: "Setup", force_relative: "Force relative", volume: "Volume", rr: "Risk/Reward", regime: "Régime" };
    html += `<div class="dsec"><h4>Plan de trade indicatif</h4><div class="kv">
      <div><span>Entrée</span><b>${price(r.entry, r.currency)}</b></div>
      <div><span>Stop</span><b class="neg">${price(r.stop)}</b></div>
      <div><span>Objectif 1</span><b class="pos">${price(r.target1)}</b></div>
      <div><span>Objectif 2</span><b>${price(r.target2)}</b></div>
      <div><span>R/R</span><b>${num(r.rr, 2)}</b></div>
      <div><span>Stop temporel</span><b>${r.time_stop} séances</b></div>
      <div><span>Taille indicative</span><b>${r.position_shares || 0} titres</b></div>
      <div><span>Montant</span><b>${num(r.position_eur, 0)} €</b></div></div>
      <ul class="plain"><li>Entrée : ${esc(r.entry_note)}</li><li>Stop : ${esc(r.stop_basis)} (risque ${pct(r.risk_pct, 1, false)})</li>
      <li>Objectif 1 : ${esc(r.target1_basis)} (potentiel ${pct(r.potential_pct, 1)})</li>${r.target2_basis ? `<li>Objectif 2 : ${esc(r.target2_basis)}</li>` : ""}</ul></div>`;
    html += `<div class="dsec"><h4>Pré-score ${num(r.prescore, 0)}/100 (technique)</h4><div class="parts">` +
      Object.keys(maxes).map((k) => `<div class="p"><span>${labels[k]}</span><div class="pb"><div style="width:${(100 * (parts[k] || 0)) / maxes[k]}%"></div></div><span class="num">${num(parts[k], 1)}/${maxes[k]}</span></div>`).join("") + `</div></div>`;
  }
  html += `<div class="dsec"><h4>Signaux</h4><ul class="plain">${(r.signal_notes || []).map((n) => `<li>${esc(n)}</li>`).join("")}</ul>
    ${r.flags && r.flags.length ? `<p class="flag">${r.flags.map(esc).join("<br>")}</p>` : ""}
    ${r.not_retained_reasons && r.not_retained_reasons.length ? `<p><strong>Non retenu :</strong> ${esc(r.not_retained_reasons.join(" · "))}</p>` : ""}</div>`;
  if (!r.light) {
    html += `<div class="dsec"><h4>Indicateurs</h4><div class="kv">
      <div><span>1 j / 5 j</span><b class="${pctCls(r.ret_1d)}">${pct(r.ret_1d)} / ${pct(r.ret_5d)}</b></div>
      <div><span>1 m / 3 m</span><b>${pct(r.ret_1m)} / ${pct(r.ret_3m)}</b></div>
      <div><span>6 m / YTD</span><b>${pct(r.ret_6m)} / ${pct(r.ret_ytd)}</b></div>
      <div><span>Dist. plus haut 52 s</span><b>${pct(r.dist_high52)}</b></div>
      <div><span>RSI14 / ADX14</span><b>${num(r.rsi, 0)} / ${num(r.adx, 0)}</b></div>
      <div><span>ATR14</span><b>${num(r.atr, 2)} (${pct(r.atr_pct, 1, false)})</b></div>
      <div><span>Volume relatif</span><b>${num(r.relvol, 2)}</b></div>
      <div><span>Vol. moyen 20 j</span><b>${big(r.adv_usd)}</b></div>
      <div><span>RS vs ${esc(r.benchmark || "indice")} 1/3/6 m</span><b>${pct(r.rs_1m, 0)} / ${pct(r.rs_3m, 0)} / ${pct(r.rs_6m, 0)}</b></div>
      <div><span>Percentile RS 3 m / 6 m</span><b>${pct(r.p_rs_3m, 0, false)} / ${pct(r.p_rs_6m, 0, false)}</b></div>
      ${isNum(r.rs_sector_3m) ? `<div><span>RS vs ETF secteur 1/3/6 m</span><b>${pct(r.rs_sector_1m, 0)} / ${pct(r.rs_sector_3m, 0)} / ${pct(r.rs_sector_6m, 0)}</b></div>` : ""}
      </div></div>
      <div class="dsec"><h4>Données de base (Yahoo, à vérifier)</h4><div class="kv">
      <div><span>Capitalisation</span><b>${big(r.market_cap_usd)}</b></div>
      <div><span>PE prospectif / hist.</span><b>${num(r.forward_pe, 1)} / ${num(r.trailing_pe, 1)}</b></div>
      <div><span>EV/EBITDA</span><b>${num(r.ev_ebitda, 1)}</b></div>
      <div><span>Croissance CA</span><b>${pct(r.revenue_growth)}</b></div>
      <div><span>Marge nette</span><b>${pct(r.profit_margin)}</b></div>
      <div><span>Short % flottant</span><b>${pct(r.short_pct_float, 1, false)}</b></div>
      <div><span>Reco. analystes (1–5)</span><b>${num(r.reco_mean, 1)} (${r.n_analysts ?? "n.d."})</b></div>
      <div><span>Prochains résultats</span><b>${dateFr(r.earnings_date)}</b></div>
      <div><span>Ex-dividende</span><b>${dateFr(r.ex_dividend_date)}</b></div></div></div>`;
  }
  html += `<div class="toolbar dsec">${!r.light && !STATIC ? `<button id="dAddJ">Ajouter au journal</button>` : ""}
    <a class="btn" href="${yahoo}" target="_blank" rel="noopener">Fiche Yahoo Finance</a>
    <a class="btn" href="${yahoo}/news" target="_blank" rel="noopener">Actualités</a><span id="dMsg" class="muted"></span></div>`;
  $("#dBody").innerHTML = html;
  const add = $("#dAddJ");
  if (add) add.addEventListener("click", async () => {
    const j = await api("/api/journal/add", { method: "POST", body: JSON.stringify({ tickers: [r.ticker] }) });
    $("#dMsg").textContent = j.added ? "Ajouté au journal." : "Déjà dans le journal pour ce scan.";
  });
  try {
    const c = await api("/api/chart/" + encodeURIComponent(r.ticker));
    drawChart(c, r);
  } catch (e) {
    const cv = $("#chart"); const ctx = cv.getContext("2d"); ctx.clearRect(0, 0, cv.width, cv.height);
    ctx.fillStyle = "gray"; ctx.fillText("Graphique indisponible : " + e.message, 20, 30);
  }
}

/* ---------------- Graphique (canvas, sans dépendance) ---------------- */
function drawChart(c, r) {
  const cv = $("#chart");
  const css = getComputedStyle(document.documentElement);
  const col = (n) => css.getPropertyValue(n).trim();
  const dpr = window.devicePixelRatio || 1;
  const W = cv.clientWidth, H = cv.clientHeight;
  cv.width = W * dpr; cv.height = H * dpr;
  const ctx = cv.getContext("2d");
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const n = c.dates.length;
  const padL = 8, padR = 64, padT = 10, volH = 60, gap = 8, priceH = H - padT - volH - gap - 22;
  const plan = c.plan || (r.entry ? r : null);
  const levels = plan ? [["entry", plan.entry, col("--entry")], ["stop", plan.stop, col("--stop")], ["target1", plan.target1, col("--target")], ["target2", plan.target2, col("--target")]].filter((x) => isNum(x[1])) : [];
  let lo = Infinity, hi = -Infinity;
  for (let i = 0; i < n; i++) { if (isNum(c.low[i])) lo = Math.min(lo, c.low[i]); if (isNum(c.high[i])) hi = Math.max(hi, c.high[i]); }
  levels.forEach((l) => { lo = Math.min(lo, l[1]); hi = Math.max(hi, l[1]); });
  const span = hi - lo || 1; lo -= span * 0.04; hi += span * 0.04;
  const cw = (W - padL - padR) / n;
  const x = (i) => padL + cw * (i + 0.5);
  const y = (v) => padT + (hi - v) / (hi - lo) * priceH;
  const draw = (hover) => {
    ctx.clearRect(0, 0, W, H);
    ctx.font = "11px " + col("--mono");
    // grille
    ctx.strokeStyle = col("--line"); ctx.lineWidth = 1; ctx.fillStyle = col("--muted");
    for (let k = 0; k <= 5; k++) {
      const v = lo + (hi - lo) * k / 5, yy = Math.round(y(v)) + 0.5;
      ctx.beginPath(); ctx.moveTo(padL, yy); ctx.lineTo(W - padR, yy); ctx.stroke();
      ctx.fillText(nf(v >= 100 ? 0 : 2).format(v), W - padR + 6, yy + 4);
    }
    // bougies
    const up = col("--up"), dn = col("--down");
    for (let i = 0; i < n; i++) {
      if (!isNum(c.close[i])) continue;
      const o = c.open[i], cl = c.close[i];
      ctx.strokeStyle = ctx.fillStyle = cl >= o ? up : dn;
      ctx.beginPath(); ctx.moveTo(Math.round(x(i)) + 0.5, y(c.high[i])); ctx.lineTo(Math.round(x(i)) + 0.5, y(c.low[i])); ctx.stroke();
      const bw = Math.max(1, cw * 0.62), top = y(Math.max(o, cl)), bh = Math.max(1, Math.abs(y(o) - y(cl)));
      ctx.fillRect(x(i) - bw / 2, top, bw, bh);
    }
    // moyennes mobiles
    [["ma20", "--ma20"], ["ma50", "--ma50"], ["ma200", "--ma200"]].forEach(([k, v]) => {
      ctx.strokeStyle = col(v); ctx.lineWidth = 1.4; ctx.beginPath(); let s = false;
      c[k].forEach((val, i) => { if (!isNum(val)) { s = false; return; } if (!s) { ctx.moveTo(x(i), y(val)); s = true; } else ctx.lineTo(x(i), y(val)); });
      ctx.stroke();
    });
    // niveaux du plan
    levels.forEach(([k, v, colr]) => {
      ctx.strokeStyle = colr; ctx.lineWidth = 1.2; ctx.setLineDash(k === "target2" ? [2, 4] : [6, 4]);
      ctx.beginPath(); ctx.moveTo(padL, y(v)); ctx.lineTo(W - padR, y(v)); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = colr; ctx.fillRect(W - padR + 2, y(v) - 8, padR - 4, 16);
      ctx.fillStyle = col("--panel"); ctx.fillText(nf(v >= 100 ? 0 : 2).format(v), W - padR + 5, y(v) + 4);
    });
    // volumes
    const vTop = padT + priceH + gap;
    const vmax = Math.max(...c.volume.filter(isNum), 1);
    for (let i = 0; i < n; i++) {
      if (!isNum(c.volume[i])) continue;
      const hgt = (c.volume[i] / vmax) * volH;
      ctx.fillStyle = (c.close[i] >= c.open[i] ? up : dn) + "66";
      ctx.fillRect(x(i) - Math.max(1, cw * 0.62) / 2, vTop + volH - hgt, Math.max(1, cw * 0.62), hgt);
    }
    // dates
    ctx.fillStyle = col("--muted");
    for (let i = 0; i < n; i += Math.ceil(n / 6)) ctx.fillText(dateFr(c.dates[i]).slice(0, 5) + "/" + c.dates[i].slice(2, 4), x(i) - 18, H - 6);
    if (hover != null) {
      ctx.strokeStyle = col("--muted"); ctx.setLineDash([3, 3]);
      ctx.beginPath(); ctx.moveTo(x(hover), padT); ctx.lineTo(x(hover), vTop + volH); ctx.stroke(); ctx.setLineDash([]);
    }
  };
  draw(null);
  const tip = $("#chartTip");
  cv.onmousemove = (e) => {
    const rect = cv.getBoundingClientRect();
    const i = Math.min(n - 1, Math.max(0, Math.floor((e.clientX - rect.left - padL) / cw)));
    draw(i);
    tip.classList.remove("hidden");
    tip.innerHTML = `${dateFr(c.dates[i])} · O ${num(c.open[i])} H ${num(c.high[i])} B ${num(c.low[i])} C ${num(c.close[i])}`;
  };
  cv.onmouseleave = () => { draw(null); tip.classList.add("hidden"); };
}

/* ---------------- Journal ---------------- */
const statusCls = (s) => (s === "objectif atteint" ? "ok" : s === "stoppé" ? "ko" : s === "en cours" ? "run" : "");
function renderJournal(j) {
  const t = j.stats.total || {};
  const cards = (j.stats.by_category || []).map((c) => `<div class="stat"><div><span class="cat ${c.categorie}">${c.categorie}</span> ${esc(c.libelle)}</div>
    <div class="big">${c.R_moyen != null ? (c.R_moyen > 0 ? "+" : "") + num(c.R_moyen, 2) + " R" : "–"}</div>
    <div class="muted">${c.signaux} signaux · ${c.declenches} déclenchés · ${c.clotures} clôturés${c.taux_reussite != null ? " · réussite " + pct(c.taux_reussite, 0, false) : ""}</div></div>`).join("");
  $("#jStats").innerHTML = `<div class="statgrid"><div class="stat"><div>Global</div><div class="big">${t.R_moyen != null ? (t.R_moyen > 0 ? "+" : "") + num(t.R_moyen, 2) + " R" : "–"}</div>
    <div class="muted">${t.signaux || 0} signaux · ${t.en_cours || 0} en cours · ${t.en_attente || 0} en attente${t.taux_reussite != null ? " · réussite " + pct(t.taux_reussite, 0, false) : ""}</div></div>${cards}</div>`;
  const cols = [
    ["Signal", (r) => dateFr(r.date_signal), "date_signal"],
    ["Titre", (r) => `<span class="tk">${esc(r.ticker)}</span> <span class="muted">${esc(r.place)}</span>`, "ticker"],
    ["Cat.", (r) => `<span class="cat ${r.categorie}">${r.categorie}</span>`, "categorie"],
    ["Score", (r) => esc(r.score), "score", "num"],
    ["Entrée", (r) => price(+r.entree), "entree", "num"],
    ["Stop", (r) => price(+r.stop), "stop", "num"],
    ["Obj. 1", (r) => price(+r.objectif1), "objectif1", "num"],
    ["Statut", (r) => `<span class="status-badge ${statusCls(r.statut)}">${esc(r.statut)}</span>`, "statut"],
    ["Exécution", (r) => (r.date_entree ? dateFr(r.date_entree) + " à " + price(+r.prix_entree) : "–"), "date_entree"],
    ["Sortie", (r) => (r.date_sortie ? dateFr(r.date_sortie) + " à " + price(+r.prix_sortie) : "–"), "date_sortie"],
    ["Résultat", (r) => (r.resultat_R !== "" ? `<span class="${+r.resultat_R >= 0 ? "pos" : "neg"}">${num(+r.resultat_R, 2)} R · ${num(+r.perf_pct, 1)} %</span>` : "–"), "resultat_R", "num"],
    ["", (r) => `<button class="ghost" data-del="${esc(r.id)}" title="Supprimer">🗑</button>`, null],
  ];
  if (STATIC) cols.pop();
  const box = $("#jBox");
  box.innerHTML = j.rows.length ? "" : '<p class="muted">Journal vide. Ajoutez les titres retenus après un scan.</p>';
  if (j.rows.length) box.appendChild(sortableTable(cols, j.rows.slice().reverse(), null));
}
$("#jBox").addEventListener("click", async (e) => {
  const b = e.target.closest("[data-del]");
  if (!b) return;
  e.stopPropagation();
  if (!confirm("Supprimer cette ligne du journal ?")) return;
  await api("/api/journal/" + b.dataset.del, { method: "DELETE" });
  loadJournal();
});
async function loadJournal() { try { renderJournal(await api("/api/journal")); } catch (e) { $("#jMsg").textContent = e.message; } }
$("#jAdd").addEventListener("click", async () => {
  try { const j = await api("/api/journal/add", { method: "POST", body: "{}" }); $("#jMsg").textContent = j.added + " ligne(s) ajoutée(s)."; loadJournal(); }
  catch (e) { $("#jMsg").textContent = e.message; }
});
$("#jUpdate").addEventListener("click", async () => {
  $("#jMsg").textContent = "Mise à jour…";
  try {
    const j = await api("/api/journal/update", { method: "POST", body: "{}" });
    renderJournal(j);
    $("#jMsg").textContent = "Statuts mis à jour" + (j.missing && j.missing.length ? ` (cours indisponibles : ${j.missing.join(", ")})` : "") + ".";
  } catch (e) { $("#jMsg").textContent = e.message; }
});

/* ---------------- Export ---------------- */
async function loadPrompt() {
  try { const j = await api("/api/export/prompt"); $("#promptBox").value = j.prompt; }
  catch (e) { $("#promptBox").value = "Lancez d'abord un scan."; }
}
$("#copyPrompt").addEventListener("click", async () => {
  const t = $("#promptBox");
  try { await navigator.clipboard.writeText(t.value); } catch { t.select(); document.execCommand("copy"); }
  $("#copyMsg").textContent = "Prompt copié.";
  setTimeout(() => ($("#copyMsg").textContent = ""), 2500);
});

/* ---------------- Paramètres ---------------- */
async function loadParams() {
  const st = await api("/api/settings");
  $$('input[name="region"]').forEach((c) => (c.checked = st.regions.includes(c.value)));
  $$('input[name="us_mode"]').forEach((c) => (c.checked = st.us_mode === c.value));
  $$("[data-k]").forEach((inp) => { const sc = +(inp.dataset.scale || 1); inp.value = +(st[inp.dataset.k] / sc).toFixed(4); });
  const u = await api("/api/universe");
  $("#perso").value = u.perso_text;
  $("#uniFolder").textContent = u.folder;
}
$("#paramsForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const body = {
    regions: $$('input[name="region"]:checked').map((c) => c.value),
    us_mode: ($('input[name="us_mode"]:checked') || {}).value || "complet",
  };
  $$("[data-k]").forEach((inp) => { const sc = +(inp.dataset.scale || 1); body[inp.dataset.k] = parseFloat(inp.value) * sc; });
  if (!body.regions.length) { $("#paramsMsg").textContent = "Cochez au moins une région."; return; }
  await api("/api/settings", { method: "POST", body: JSON.stringify(body) });
  $("#paramsMsg").textContent = "Enregistré. Appliqué au prochain scan.";
});
$("#savePerso").addEventListener("click", async () => {
  const j = await api("/api/universe/perso", { method: "POST", body: JSON.stringify({ text: $("#perso").value }) });
  $("#persoMsg").textContent = j.count + " ticker(s) enregistré(s).";
});

/* ---------------- Démarrage ---------------- */
(async () => {
  if (STATIC) {
    $("#dlCsv").href = "data/radar.csv";
    $("#jCsv").href = "data/journal.csv";
    try {
      const site = await (await fetch("data/site.json?v=" + Date.now())).json();
      $("#runNow").href = site.actions_url;
      $("#editParams").href = site.edit_params_url;
      $("#editPerso").href = site.edit_perso_url;
      $("#runNow").title = site.schedule + " — cliquez puis « Run workflow » pour relancer maintenant.";
    } catch {}
  }
  await loadHistory();
  await loadResult();
  const s = await api("/api/status");
  $("#demoBanner").classList.toggle("hidden", !s.demo);
  if (s.running) startPolling();
})();
